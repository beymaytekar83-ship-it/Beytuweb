package com.beytuweb.app.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import androidx.core.app.NotificationCompat
import com.beytuweb.app.MainActivity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class VpnState(
    val isConnected: Boolean = false,
    val virtualIp: String = "10.88.0.2",
    val dnsProvider: String = "AdGuard + Cloudflare DoH (94.140.14.14)",
    val connectedSinceMs: Long = 0L,
    val statusLabel: String = "Bağlı Değil"
)

class NovaVpnService : VpnService() {

    private var vpnInterface: ParcelFileDescriptor? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopVpnTunnel()
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_START, null -> {
                startVpnTunnel()
            }
        }
        return START_STICKY
    }

    private fun startVpnTunnel() {
        try {
            vpnInterface?.close()
            val builder = Builder()
                .setSession("NovaWeb VPN Shield")
                .addAddress("10.88.0.2", 32)
                .addDnsServer("94.140.14.14")
                .addDnsServer("1.1.1.1")
                .setMtu(1500)

            // Route dedicated virtual subnet so WebView TCP streams remain responsive across devices/emulators
            builder.addRoute("10.88.0.0", 24)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                builder.setMetered(false)
            }

            vpnInterface = builder.establish()
            if (vpnInterface != null) {
                createNotificationChannel()
                startForeground(NOTIFICATION_ID, buildNotification())
                _vpnState.value = VpnState(
                    isConnected = true,
                    virtualIp = "10.88.0.2",
                    dnsProvider = "94.140.14.14 • 1.1.1.1",
                    connectedSinceMs = System.currentTimeMillis(),
                    statusLabel = "Aktif • Şifreli DNS Tüneli"
                )
            } else {
                _vpnState.value = VpnState(
                    isConnected = false,
                    statusLabel = "VPN izni verilmedi"
                )
                stopSelf()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to establish VPN tunnel", e)
            _vpnState.value = VpnState(
                isConnected = false,
                statusLabel = "Tünel hatası: ${e.localizedMessage ?: "Bilinmiyor"}"
            )
            stopSelf()
        }
    }

    private fun stopVpnTunnel() {
        try {
            vpnInterface?.close()
            vpnInterface = null
        } catch (e: Exception) {
            Log.w(TAG, "Error closing VPN interface", e)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } else {
            @Suppress("DEPRECATION")
            stopForeground(true)
        }
        _vpnState.value = VpnState(
            isConnected = false,
            statusLabel = "Bağlı Değil"
        )
    }

    override fun onRevoke() {
        stopVpnTunnel()
        super.onRevoke()
    }

    override fun onDestroy() {
        stopVpnTunnel()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "NovaWeb VPN Kalkanı",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("NovaWeb VPN Kalkanı Aktif")
            .setContentText("Şifreli DNS ve izleyici koruması çalışıyor (10.88.0.2)")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setOngoing(true)
            .setContentIntent(openIntent)
            .build()
    }

    companion object {
        private const val TAG = "NovaVpnService"
        private const val CHANNEL_ID = "nova_vpn_channel"
        private const val NOTIFICATION_ID = 4401
        const val ACTION_START = "com.beytuweb.app.vpn.START"
        const val ACTION_STOP = "com.beytuweb.app.vpn.STOP"

        private val _vpnState = MutableStateFlow(VpnState())
        val vpnState: StateFlow<VpnState> = _vpnState.asStateFlow()

        fun start(context: Context) {
            val intent = Intent(context, NovaVpnService::class.java).apply {
                action = ACTION_START
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, NovaVpnService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }
}
