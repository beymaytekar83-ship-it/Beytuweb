package com.beytuweb.app.data.prefs

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "novaweb_prefs")

data class BrowserPreferences(
    val darkThemeEnabled: Boolean = true,
    val webForceDarkEnabled: Boolean = true,
    val adBlockEnabled: Boolean = true,
    val desktopModeDefault: Boolean = false,
    val aiAutoAnswerEnabled: Boolean = true,
    val searchEngine: String = "Google",
    val translationTargetLang: String = "Türkçe",
    val syncAccountEmail: String = "beymaytekar83@gmail.com",
    val adsBlockedCount: Long = 0L,
    val lastBackupTimestamp: Long = 0L
)

class UserPreferencesRepository(private val context: Context) {

    private object Keys {
        val DARK_THEME = booleanPreferencesKey("dark_theme_enabled")
        val WEB_FORCE_DARK = booleanPreferencesKey("web_force_dark_enabled")
        val AD_BLOCK = booleanPreferencesKey("ad_block_enabled")
        val DESKTOP_MODE = booleanPreferencesKey("desktop_mode_default")
        val AI_AUTO_ANSWER = booleanPreferencesKey("ai_auto_answer_enabled")
        val SEARCH_ENGINE = stringPreferencesKey("search_engine")
        val TRANSLATION_LANG = stringPreferencesKey("translation_target_lang")
        val SYNC_EMAIL = stringPreferencesKey("sync_account_email")
        val ADS_BLOCKED = longPreferencesKey("ads_blocked_count")
        val LAST_BACKUP = longPreferencesKey("last_backup_timestamp")
    }

    val preferencesFlow: Flow<BrowserPreferences> = context.dataStore.data.map { prefs ->
        BrowserPreferences(
            darkThemeEnabled = prefs[Keys.DARK_THEME] ?: true,
            webForceDarkEnabled = prefs[Keys.WEB_FORCE_DARK] ?: true,
            adBlockEnabled = prefs[Keys.AD_BLOCK] ?: true,
            desktopModeDefault = prefs[Keys.DESKTOP_MODE] ?: false,
            aiAutoAnswerEnabled = prefs[Keys.AI_AUTO_ANSWER] ?: true,
            searchEngine = prefs[Keys.SEARCH_ENGINE] ?: "Google",
            translationTargetLang = prefs[Keys.TRANSLATION_LANG] ?: "Türkçe",
            syncAccountEmail = prefs[Keys.SYNC_EMAIL] ?: "beymaytekar83@gmail.com",
            adsBlockedCount = prefs[Keys.ADS_BLOCKED] ?: 0L,
            lastBackupTimestamp = prefs[Keys.LAST_BACKUP] ?: 0L
        )
    }

    suspend fun setDarkTheme(enabled: Boolean) {
        context.dataStore.edit { it[Keys.DARK_THEME] = enabled }
    }

    suspend fun setWebForceDark(enabled: Boolean) {
        context.dataStore.edit { it[Keys.WEB_FORCE_DARK] = enabled }
    }

    suspend fun setAdBlock(enabled: Boolean) {
        context.dataStore.edit { it[Keys.AD_BLOCK] = enabled }
    }

    suspend fun setDesktopModeDefault(enabled: Boolean) {
        context.dataStore.edit { it[Keys.DESKTOP_MODE] = enabled }
    }

    suspend fun setAiAutoAnswer(enabled: Boolean) {
        context.dataStore.edit { it[Keys.AI_AUTO_ANSWER] = enabled }
    }

    suspend fun setSearchEngine(engine: String) {
        context.dataStore.edit { it[Keys.SEARCH_ENGINE] = engine }
    }

    suspend fun setTranslationLanguage(language: String) {
        context.dataStore.edit { it[Keys.TRANSLATION_LANG] = language }
    }

    suspend fun setSyncAccountEmail(email: String) {
        context.dataStore.edit { it[Keys.SYNC_EMAIL] = email }
    }

    suspend fun incrementAdsBlocked(delta: Long = 1L) {
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.ADS_BLOCKED] ?: 0L
            prefs[Keys.ADS_BLOCKED] = current + delta
        }
    }

    suspend fun setLastBackupTimestamp(timestamp: Long) {
        context.dataStore.edit { it[Keys.LAST_BACKUP] = timestamp }
    }
}
