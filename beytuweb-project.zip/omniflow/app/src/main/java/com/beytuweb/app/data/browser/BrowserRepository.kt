package com.beytuweb.app.data.browser

import com.beytuweb.app.chromeimport.ChromeDataImporter
import com.beytuweb.app.chromeimport.ChromeImportResult
import com.beytuweb.app.data.local.BookmarkEntity
import com.beytuweb.app.data.local.DownloadEntity
import com.beytuweb.app.data.local.HistoryEntity
import com.beytuweb.app.data.local.NovaDao
import com.beytuweb.app.data.local.ShortcutEntity
import com.beytuweb.app.data.prefs.BrowserPreferences
import com.beytuweb.app.data.prefs.UserPreferencesRepository
import kotlinx.coroutines.flow.Flow

class BrowserRepository(
    private val dao: NovaDao,
    private val prefsRepo: UserPreferencesRepository
) {
    val bookmarks: Flow<List<BookmarkEntity>> = dao.observeBookmarks()
    val history: Flow<List<HistoryEntity>> = dao.observeHistory()
    val shortcuts: Flow<List<ShortcutEntity>> = dao.observeShortcuts()
    val downloads: Flow<List<DownloadEntity>> = dao.observeDownloads()
    val preferences: Flow<BrowserPreferences> = prefsRepo.preferencesFlow

    suspend fun ensureDefaultsSeeded() {
        if (dao.getShortcutCount() == 0) {
            dao.insertShortcuts(
                listOf(
                    ShortcutEntity(title = "YouTube", url = "https://m.youtube.com", badgeLetter = "Y", accentHex = 0xFFEF4444, sortOrder = 0),
                    ShortcutEntity(title = "TikTok", url = "https://www.tiktok.com", badgeLetter = "T", accentHex = 0xFF00E5FF, sortOrder = 1),
                    ShortcutEntity(title = "Google", url = "https://www.google.com", badgeLetter = "G", accentHex = 0xFF10B981, sortOrder = 2),
                    ShortcutEntity(title = "Gmail", url = "https://mail.google.com", badgeLetter = "M", accentHex = 0xFFF59E0B, sortOrder = 3),
                    ShortcutEntity(title = "GitHub", url = "https://github.com", badgeLetter = "H", accentHex = 0xFFA855F7, sortOrder = 4),
                    ShortcutEntity(title = "Vikipedi", url = "https://tr.wikipedia.org", badgeLetter = "V", accentHex = 0xFF38BDF8, sortOrder = 5)
                )
            )
            dao.insertBookmarks(
                listOf(
                    BookmarkEntity(title = "YouTube", url = "https://m.youtube.com", folder = "Video"),
                    BookmarkEntity(title = "TikTok", url = "https://www.tiktok.com", folder = "Sosyal"),
                    BookmarkEntity(title = "Gmail", url = "https://mail.google.com", folder = "Araçlar"),
                    BookmarkEntity(title = "GitHub", url = "https://github.com", folder = "Geliştirici")
                )
            )
        }
    }

    fun observeIsBookmarked(url: String): Flow<Boolean> = dao.observeIsBookmarked(url)

    suspend fun toggleBookmark(title: String, url: String, folder: String = "Genel"): Boolean {
        val existing = dao.getBookmarksOnce().firstOrNull { it.url.equals(url, ignoreCase = true) }
        return if (existing != null) {
            dao.deleteBookmark(existing.id)
            false
        } else {
            dao.insertBookmark(BookmarkEntity(title = title.ifBlank { url }, url = url, folder = folder))
            true
        }
    }

    suspend fun addBookmark(title: String, url: String, folder: String) {
        dao.insertBookmark(BookmarkEntity(title = title.ifBlank { url }, url = url, folder = folder.ifBlank { "Genel" }))
    }

    suspend fun updateBookmark(bookmark: BookmarkEntity) = dao.updateBookmark(bookmark)

    suspend fun deleteBookmark(id: Long) = dao.deleteBookmark(id)

    suspend fun recordHistory(title: String, url: String) {
        if (url.isBlank() || url.startsWith("about:") || url.startsWith("data:")) return
        dao.insertHistory(HistoryEntity(title = title.ifBlank { url }, url = url))
    }

    suspend fun deleteHistoryItem(id: Long) = dao.deleteHistoryItem(id)

    suspend fun clearHistory() = dao.clearHistory()

    suspend fun addShortcut(title: String, url: String, accentHex: Long) {
        val letter = title.trim().firstOrNull()?.uppercaseChar()?.toString() ?: "W"
        val order = dao.getShortcutCount()
        dao.insertShortcut(
            ShortcutEntity(
                title = title.trim(),
                url = url.trim(),
                badgeLetter = letter,
                accentHex = accentHex,
                sortOrder = order
            )
        )
    }

    suspend fun deleteShortcut(id: Long) = dao.deleteShortcut(id)

    suspend fun importChromeOrBackup(rawContent: String): ChromeImportResult {
        val parsed = ChromeDataImporter.parseImportedText(rawContent)
        if (parsed.bookmarks.isNotEmpty()) {
            dao.insertBookmarks(parsed.bookmarks)
        }
        if (parsed.history.isNotEmpty()) {
            dao.insertHistoryBatch(parsed.history)
        }
        if (parsed.shortcuts.isNotEmpty()) {
            dao.insertShortcuts(parsed.shortcuts)
        }
        return parsed
    }

    suspend fun createBackupJson(accountEmail: String): String {
        val b = dao.getBookmarksOnce()
        val h = dao.getHistoryOnce()
        val s = dao.getShortcutsOnce()
        prefsRepo.setLastBackupTimestamp(System.currentTimeMillis())
        return ChromeDataImporter.exportNovaBackupJson(b, h, s, accountEmail)
    }

    suspend fun setDarkTheme(enabled: Boolean) = prefsRepo.setDarkTheme(enabled)
    suspend fun setWebForceDark(enabled: Boolean) = prefsRepo.setWebForceDark(enabled)
    suspend fun setAdBlock(enabled: Boolean) = prefsRepo.setAdBlock(enabled)
    suspend fun setDesktopModeDefault(enabled: Boolean) = prefsRepo.setDesktopModeDefault(enabled)
    suspend fun setAiAutoAnswer(enabled: Boolean) = prefsRepo.setAiAutoAnswer(enabled)
    suspend fun setSearchEngine(engine: String) = prefsRepo.setSearchEngine(engine)
    suspend fun setTranslationLanguage(language: String) = prefsRepo.setTranslationLanguage(language)
    suspend fun setSyncAccountEmail(email: String) = prefsRepo.setSyncAccountEmail(email)
    suspend fun incrementAdsBlocked() = prefsRepo.incrementAdsBlocked(1L)
}
