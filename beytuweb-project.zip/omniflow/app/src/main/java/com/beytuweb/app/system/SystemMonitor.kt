package com.beytuweb.app.system

import android.app.ActivityManager
import android.content.Context
import android.net.TrafficStats
import android.os.Debug
import android.os.Process
import android.webkit.WebView
import java.io.File

data class SystemTelemetry(
    val totalRamMb: Long = 0L,
    val availableRamMb: Long = 0L,
    val usedRamPercent: Float = 0f,
    val appHeapMb: Float = 0f,
    val nativeHeapMb: Float = 0f,
    val webCacheMb: Float = 0f,
    val networkRxMb: Float = 0f,
    val networkTxMb: Float = 0f,
    val activeTabsCount: Int = 1
)

object SystemMonitor {

    fun collectTelemetry(context: Context, activeTabsCount: Int): SystemTelemetry {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        am.getMemoryInfo(memInfo)

        val totalMb = memInfo.totalMem / (1024L * 1024L)
        val availMb = memInfo.availMem / (1024L * 1024L)
        val usedPct = if (totalMb > 0) ((totalMb - availMb).toFloat() / totalMb.toFloat()).coerceIn(0f, 1f) else 0f

        val runtime = Runtime.getRuntime()
        val jvmUsedMb = (runtime.totalMemory() - runtime.freeMemory()) / (1024f * 1024f)
        val nativeMb = Debug.getNativeHeapAllocatedSize() / (1024f * 1024f)

        val cacheBytes = calculateDirSize(context.cacheDir)
        val cacheMb = cacheBytes / (1024f * 1024f)

        val uid = Process.myUid()
        val rxBytes = TrafficStats.getUidRxBytes(uid).coerceAtLeast(0L)
        val txBytes = TrafficStats.getUidTxBytes(uid).coerceAtLeast(0L)

        return SystemTelemetry(
            totalRamMb = totalMb,
            availableRamMb = availMb,
            usedRamPercent = usedPct,
            appHeapMb = jvmUsedMb,
            nativeHeapMb = nativeMb,
            webCacheMb = cacheMb,
            networkRxMb = rxBytes / (1024f * 1024f),
            networkTxMb = txBytes / (1024f * 1024f),
            activeTabsCount = activeTabsCount
        )
    }

    fun optimizeMemory(context: Context, activeWebViews: Collection<WebView>): Float {
        val beforeCache = calculateDirSize(context.cacheDir)
        activeWebViews.forEach { webView ->
            try {
                webView.clearCache(false)
                webView.freeMemory()
            } catch (_: Exception) {
            }
        }
        deleteCacheContents(context.cacheDir)
        System.gc()
        val afterCache = calculateDirSize(context.cacheDir)
        return ((beforeCache - afterCache).coerceAtLeast(0L)) / (1024f * 1024f)
    }

    private fun calculateDirSize(dir: File?): Long {
        if (dir == null || !dir.exists()) return 0L
        if (dir.isFile) return dir.length()
        var total = 0L
        dir.listFiles()?.forEach { child ->
            total += calculateDirSize(child)
        }
        return total
    }

    private fun deleteCacheContents(dir: File?) {
        if (dir == null || !dir.exists()) return
        dir.listFiles()?.forEach { child ->
            if (child.isDirectory) {
                deleteCacheContents(child)
                child.delete()
            } else {
                child.delete()
            }
        }
    }
}
