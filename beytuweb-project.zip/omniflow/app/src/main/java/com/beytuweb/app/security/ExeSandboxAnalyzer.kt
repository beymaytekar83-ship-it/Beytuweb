package com.beytuweb.app.security

import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class PeSectionInfo(
    val name: String,
    val virtualSize: Int,
    val rawSize: Int,
    val isExecutable: Boolean,
    val isWritable: Boolean
)

data class ExeSandboxReport(
    val fileName: String,
    val fileSizeBytes: Long,
    val isValidPe: Boolean,
    val architecture: String,
    val peFormat: String,
    val subsystem: String,
    val compiledAt: String,
    val entryPointHex: String,
    val sections: List<PeSectionInfo>,
    val detectedApis: List<String>,
    val riskScore: Int,
    val verdict: String,
    val findings: List<String>
)

object ExeSandboxAnalyzer {

    private val suspiciousApis = listOf(
        "VirtualAlloc",
        "VirtualProtect",
        "CreateRemoteThread",
        "WriteProcessMemory",
        "ReadProcessMemory",
        "WinExec",
        "ShellExecuteA",
        "ShellExecuteW",
        "URLDownloadToFileA",
        "URLDownloadToFileW",
        "InternetOpenA",
        "RegSetValueExA",
        "SetWindowsHookExA",
        "IsDebuggerPresent",
        "GetProcAddress",
        "LoadLibraryA",
        "CreateProcessA"
    )

    fun inspect(file: File): ExeSandboxReport {
        if (!file.exists()) {
            return ExeSandboxReport(
                fileName = file.name,
                fileSizeBytes = 0L,
                isValidPe = false,
                architecture = "Bilinmiyor",
                peFormat = "Yok",
                subsystem = "Yok",
                compiledAt = "-",
                entryPointHex = "-",
                sections = emptyList(),
                detectedApis = emptyList(),
                riskScore = 0,
                verdict = "Dosya erişilemiyor",
                findings = listOf("Dosya diskte bulunamadı.")
            )
        }

        val bytes = file.readBytes()
        val buf = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        val findings = mutableListOf<String>()
        var riskScore = 10

        val hasMz = bytes.size >= 64 && bytes[0] == 0x4D.toByte() && bytes[1] == 0x5A.toByte()
        if (!hasMz) {
            findings += "Geçerli DOS 'MZ' başlığı bulunamadı — bozuk veya farklı biçimli dosya."
            val apis = scanStrings(bytes)
            if (apis.isNotEmpty()) riskScore += 20
            return ExeSandboxReport(
                fileName = file.name,
                fileSizeBytes = file.length(),
                isValidPe = false,
                architecture = "Bilinmiyor",
                peFormat = "PE Değil",
                subsystem = "-",
                compiledAt = "-",
                entryPointHex = "-",
                sections = emptyList(),
                detectedApis = apis,
                riskScore = riskScore.coerceIn(0, 100),
                verdict = "Geçersiz PE İkili Dosyası",
                findings = findings
            )
        }

        val peOffset = buf.getInt(0x3C)
        if (peOffset < 0 || peOffset + 24 > bytes.size ||
            bytes[peOffset] != 0x50.toByte() || bytes[peOffset + 1] != 0x45.toByte() ||
            bytes[peOffset + 2] != 0x00.toByte() || bytes[peOffset + 3] != 0x00.toByte()
        ) {
            findings += "MZ başlığı mevcut ancak PE\\0\\0 imzası geçersiz."
            return ExeSandboxReport(
                fileName = file.name,
                fileSizeBytes = file.length(),
                isValidPe = false,
                architecture = "DOS / Bozuk PE",
                peFormat = "DOS-MZ",
                subsystem = "-",
                compiledAt = "-",
                entryPointHex = "-",
                sections = emptyList(),
                detectedApis = scanStrings(bytes),
                riskScore = 45,
                verdict = "Bozuk veya Gizlenmiş PE Başlığı",
                findings = findings
            )
        }

        val coffOffset = peOffset + 4
        val machine = buf.getShort(coffOffset).toInt() and 0xFFFF
        val numSections = (buf.getShort(coffOffset + 2).toInt() and 0xFFFF).coerceAtMost(32)
        val timestampSec = buf.getInt(coffOffset + 4).toLong() and 0xFFFFFFFFL
        val optionalSize = buf.getShort(coffOffset + 16).toInt() and 0xFFFF
        val characteristics = buf.getShort(coffOffset + 18).toInt() and 0xFFFF

        val arch = when (machine) {
            0x014c -> "x86 (32-bit)"
            0x8664 -> "x64 (AMD64)"
            0xAA64 -> "ARM64"
            else -> "0x${machine.toString(16).uppercase()}"
        }

        val compiledStr = if (timestampSec > 0L) {
            SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(timestampSec * 1000L))
        } else {
            "Sıfırlanmış / Bilinmiyor"
        }

        val optOffset = coffOffset + 20
        var peFormat = "PE32"
        var entryPointHex = "0x00000000"
        var subsystem = "Bilinmiyor"

        if (optOffset + 70 <= bytes.size && optionalSize >= 70) {
            val magic = buf.getShort(optOffset).toInt() and 0xFFFF
            peFormat = when (magic) {
                0x10B -> "PE32 (32-bit)"
                0x20B -> "PE32+ (64-bit)"
                else -> "0x${magic.toString(16)}"
            }
            val ep = buf.getInt(optOffset + 16).toLong() and 0xFFFFFFFFL
            entryPointHex = "0x${ep.toString(16).uppercase().padStart(8, '0')}"
            val subCode = buf.getShort(optOffset + 68).toInt() and 0xFFFF
            subsystem = when (subCode) {
                1 -> "Native / Sürücü"
                2 -> "Windows GUI"
                3 -> "Windows Konsol (CLI)"
                else -> "Alt Sistem #$subCode"
            }
        }

        val isDll = (characteristics and 0x2000) != 0
        if (isDll) {
            findings += "Dosya bir DLL kütüphanesi olarak işaretlenmiş."
        }

        val sectionTableOffset = optOffset + optionalSize
        val sections = mutableListOf<PeSectionInfo>()
        for (i in 0 until numSections) {
            val sOff = sectionTableOffset + i * 40
            if (sOff + 40 > bytes.size) break
            val rawName = bytes.copyOfRange(sOff, sOff + 8)
            val name = rawName.takeWhile { it != 0.toByte() }.toByteArray().decodeToString()
            val vSize = buf.getInt(sOff + 8)
            val rSize = buf.getInt(sOff + 16)
            val secChars = buf.getInt(sOff + 36)
            val isExec = (secChars and 0x20000000) != 0
            val isWrite = (secChars and 0x80000000.toInt()) != 0
            sections += PeSectionInfo(
                name = name.ifBlank { "sec_$i" },
                virtualSize = vSize,
                rawSize = rSize,
                isExecutable = isExec,
                isWritable = isWrite
            )

            if (isExec && isWrite) {
                riskScore += 20
                findings += "'$name' bölümü hem çalıştırılabilir hem yazılabilir (RWX) — kendini değiştiren kod göstergesi."
            }
            if (name.lowercase().contains("upx")) {
                riskScore += 20
                findings += "UPX paketleyici bölümü tespit edildi ($name)."
            }
        }

        val detectedApis = scanStrings(bytes)
        val criticalInjectApis = detectedApis.filter {
            it in listOf("CreateRemoteThread", "WriteProcessMemory", "VirtualAlloc", "URLDownloadToFileA", "URLDownloadToFileW")
        }
        if (criticalInjectApis.isNotEmpty()) {
            riskScore += 30
            findings += "Yüksek riskli bellek/ağ API çağrıları tespit edildi: ${criticalInjectApis.joinToString(", ")}"
        } else if (detectedApis.isNotEmpty()) {
            riskScore += 12
            findings += "Sistem/ağ API referansları tespit edildi (${detectedApis.size} adet)."
        }

        riskScore = riskScore.coerceIn(0, 100)
        val verdict = when {
            riskScore >= 60 -> "TEHLİKELİ • İzole Edildi (Çalıştırılmadı)"
            riskScore >= 30 -> "ŞÜPHELİ • Sandbox İncelemesi Önerilir"
            else -> "DÜŞÜK RİSK • Güvenli Statik İmza"
        }

        return ExeSandboxReport(
            fileName = file.name,
            fileSizeBytes = file.length(),
            isValidPe = true,
            architecture = arch,
            peFormat = peFormat,
            subsystem = subsystem,
            compiledAt = compiledStr,
            entryPointHex = entryPointHex,
            sections = sections,
            detectedApis = detectedApis,
            riskScore = riskScore,
            verdict = verdict,
            findings = findings
        )
    }

    private fun scanStrings(bytes: ByteArray): List<String> {
        val text = bytes.decodeToString()
        return suspiciousApis.filter { api -> text.contains(api, ignoreCase = false) }
    }

    fun createHarmlessSampleExe(targetDir: File): File {
        if (!targetDir.exists()) targetDir.mkdirs()
        val file = File(targetDir, "nova_sandbox_test.exe")
        val bytes = ByteArray(1024)
        val buf = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)

        bytes[0] = 0x4D
        bytes[1] = 0x5A
        buf.putInt(0x3C, 0x80)

        bytes[0x80] = 0x50
        bytes[0x81] = 0x45
        bytes[0x82] = 0x00
        bytes[0x83] = 0x00

        val coff = 0x84
        buf.putShort(coff, 0x8664.toShort())
        buf.putShort(coff + 2, 2.toShort())
        buf.putInt(coff + 4, (System.currentTimeMillis() / 1000L).toInt())
        buf.putShort(coff + 16, 0xF0.toShort())
        buf.putShort(coff + 18, 0x0022.toShort())

        val opt = coff + 20
        buf.putShort(opt, 0x20B.toShort())
        buf.putInt(opt + 16, 0x1000)
        buf.putShort(opt + 68, 3.toShort())

        val sec1 = opt + 0xF0
        ".text".toByteArray().copyInto(bytes, sec1)
        buf.putInt(sec1 + 8, 512)
        buf.putInt(sec1 + 16, 512)
        buf.putInt(sec1 + 36, 0x60000020)

        val sec2 = sec1 + 40
        ".rdata".toByteArray().copyInto(bytes, sec2)
        buf.putInt(sec2 + 8, 256)
        buf.putInt(sec2 + 16, 256)
        buf.putInt(sec2 + 36, 0x40000040)

        val demoStrings = "GetProcAddress\u0000LoadLibraryA\u0000VirtualAlloc\u0000InternetOpenA\u0000NovaWebSafeSample\u0000".toByteArray()
        demoStrings.copyInto(bytes, 768)

        FileOutputStream(file).use { it.write(bytes) }
        return file
    }
}
