package com.beytuweb.app.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.beytuweb.app.data.ai.AiResponse
import com.beytuweb.app.data.local.DownloadEntity
import com.beytuweb.app.data.local.DownloadStatus
import com.beytuweb.app.data.local.ScanStatus
import com.beytuweb.app.security.ExeSandboxReport
import com.beytuweb.app.ui.theme.NovaAmber
import com.beytuweb.app.ui.theme.NovaCrimson
import com.beytuweb.app.ui.theme.NovaCyan
import com.beytuweb.app.ui.theme.NovaEmerald
import com.beytuweb.app.ui.theme.NovaViolet

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DownloadsScreen(
    downloads: List<DownloadEntity>,
    sandboxReport: ExeSandboxReport?,
    sandboxAiNote: AiResponse?,
    onBack: () -> Unit,
    onStartDownload: (String) -> Unit,
    onPauseDownload: (Long) -> Unit,
    onResumeDownload: (Long) -> Unit,
    onDeleteDownload: (DownloadEntity) -> Unit,
    onCreateSampleExe: () -> Unit,
    onInspectExeInSandbox: (DownloadEntity) -> Unit,
    onCloseSandboxDialog: () -> Unit
) {
    BackHandler(onBack = onBack)

    val categories = listOf("Tümü", "Görseller", "Videolar", "Belgeler", "Ses", "Arşivler", "Çalıştırılabilir", "Diğer")
    var selectedCategory by remember { mutableStateOf("Tümü") }
    var customUrl by remember { mutableStateOf("") }

    val filtered = remember(downloads, selectedCategory) {
        if (selectedCategory == "Tümü") downloads else downloads.filter { it.category == selectedCategory }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("İndirilenler & Güvenlik") },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.minimumInteractiveComponentSize()) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Geri")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 720.dp)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Direct URL Downloader + Sample .exe Sandbox Trigger
                Surface(
                    shape = MaterialTheme.shapes.medium,
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = customUrl,
                                onValueChange = { customUrl = it },
                                placeholder = { Text("Dosya URL'si yapıştırın...") },
                                singleLine = true,
                                modifier = Modifier.weight(1f).testTag("download_url_input")
                            )
                            Button(
                                onClick = {
                                    if (customUrl.isNotBlank()) {
                                        onStartDownload(customUrl)
                                        customUrl = ""
                                    }
                                },
                                modifier = Modifier.testTag("start_download_button")
                            ) {
                                Icon(Icons.Filled.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("İndir")
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Çıksanız bile arka planda devam eder • Tür klasörleme aktif",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedButton(
                                onClick = onCreateSampleExe,
                                modifier = Modifier.testTag("create_sample_exe_button")
                            ) {
                                Icon(Icons.Filled.BugReport, contentDescription = null, tint = NovaAmber, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Örnek .EXE Testi")
                            }
                        }
                    }
                }

                // Category Folders Bar
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(categories) { cat ->
                        val count = if (cat == "Tümü") downloads.size else downloads.count { it.category == cat }
                        FilterChip(
                            selected = selectedCategory == cat,
                            onClick = { selectedCategory = cat },
                            leadingIcon = { Icon(Icons.Filled.Folder, contentDescription = null, modifier = Modifier.size(15.dp)) },
                            label = { Text("$cat ($count)") }
                        )
                    }
                }
            }

            if (filtered.isEmpty()) {
                Column(
                    modifier = Modifier.fillMaxSize().padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(Icons.Filled.Shield, contentDescription = null, tint = NovaEmerald, modifier = Modifier.size(48.dp))
                    Spacer(Modifier.height(12.dp))
                    Text("Bu klasörde dosya yok", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Dosyalar indirildiğinde türüne göre klasörlenir, antivirüs taramasından geçer ve .exe dosyaları sandbox'ta incelenir.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize().widthIn(max = 720.dp),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filtered, key = { it.id }) { item ->
                        DownloadItemCard(
                            item = item,
                            onPause = { onPauseDownload(item.id) },
                            onResume = { onResumeDownload(item.id) },
                            onDelete = { onDeleteDownload(item) },
                            onInspectSandbox = { onInspectExeInSandbox(item) }
                        )
                    }
                }
            }
        }
    }

    if (sandboxReport != null) {
        ExeSandboxDialog(
            report = sandboxReport,
            aiNote = sandboxAiNote,
            onDismiss = onCloseSandboxDialog
        )
    }
}

@Composable
private fun DownloadItemCard(
    item: DownloadEntity,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onDelete: () -> Unit,
    onInspectSandbox: () -> Unit
) {
    val statusEnum = runCatching { DownloadStatus.valueOf(item.status) }.getOrDefault(DownloadStatus.QUEUED)
    val scanEnum = runCatching { ScanStatus.valueOf(item.scanStatus) }.getOrDefault(ScanStatus.PENDING)
    val scanColor = when (scanEnum) {
        ScanStatus.CLEAN -> NovaEmerald
        ScanStatus.SUSPICIOUS -> NovaAmber
        ScanStatus.THREAT -> NovaCrimson
        else -> NovaCyan
    }

    Card(
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Folder, contentDescription = null, tint = NovaCyan, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(item.fileName, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        text = "Klasör: Downloads/${item.category} • ${formatBytes(item.downloadedBytes)}" +
                            if (item.totalBytes > 0) " / ${formatBytes(item.totalBytes)}" else "",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                if (statusEnum == DownloadStatus.DOWNLOADING) {
                    IconButton(onClick = onPause, modifier = Modifier.minimumInteractiveComponentSize().testTag("pause_download_${item.id}")) {
                        Icon(Icons.Filled.Pause, contentDescription = "Duraklat", tint = NovaAmber)
                    }
                } else if (statusEnum == DownloadStatus.PAUSED || statusEnum == DownloadStatus.FAILED) {
                    IconButton(onClick = onResume, modifier = Modifier.minimumInteractiveComponentSize().testTag("resume_download_${item.id}")) {
                        Icon(Icons.Filled.PlayArrow, contentDescription = "Devam et", tint = NovaEmerald)
                    }
                }
                IconButton(onClick = onDelete, modifier = Modifier.minimumInteractiveComponentSize()) {
                    Icon(Icons.Filled.Delete, contentDescription = "Sil", tint = MaterialTheme.colorScheme.error)
                }
            }

            if (statusEnum == DownloadStatus.DOWNLOADING || statusEnum == DownloadStatus.PAUSED) {
                val progress = if (item.totalBytes > 0) (item.downloadedBytes.toFloat() / item.totalBytes.toFloat()).coerceIn(0f, 1f) else 0f
                if (item.totalBytes > 0) {
                    LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
                } else {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                }
                Text(
                    text = if (statusEnum == DownloadStatus.PAUSED) "Duraklatıldı — devam ettirilmeye hazır" else "İndiriliyor (arka plan korumalı)...",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (statusEnum == DownloadStatus.PAUSED) NovaAmber else NovaCyan
                )
            }

            // Antivirus Scan Pill
            Surface(
                color = scanColor.copy(alpha = 0.14f),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, scanColor.copy(alpha = 0.4f))
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (scanEnum == ScanStatus.CLEAN) Icons.Filled.CheckCircle else Icons.Filled.Warning,
                        contentDescription = null,
                        tint = scanColor,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Antivirüs: ${item.scanSummary}",
                            style = MaterialTheme.typography.bodySmall,
                            color = scanColor
                        )
                        if (item.sha256.isNotBlank()) {
                            Text(
                                text = "SHA-256: ${item.sha256.take(22)}...",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            if (item.isExecutable && statusEnum == DownloadStatus.COMPLETED) {
                Button(
                    onClick = onInspectSandbox,
                    colors = ButtonDefaults.buttonColors(containerColor = NovaViolet),
                    modifier = Modifier.fillMaxWidth().testTag("inspect_sandbox_${item.id}")
                ) {
                    Icon(Icons.Filled.Security, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Çalıştırmadan Önce Sandbox'ta Analiz Et")
                }
            }
        }
    }
}

@Composable
fun ExeSandboxDialog(
    report: ExeSandboxReport,
    aiNote: AiResponse?,
    onDismiss: () -> Unit
) {
    val riskColor = when {
        report.riskScore >= 60 -> NovaCrimson
        report.riskScore >= 30 -> NovaAmber
        else -> NovaEmerald
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Filled.Security, contentDescription = null, tint = riskColor) },
        title = { Text("İzole .EXE Sandbox Analizi") },
        text = {
            Column(
                modifier = Modifier
                    .heightIn(max = 420.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    color = riskColor.copy(alpha = 0.16f),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, riskColor)
                ) {
                    Column(modifier = Modifier.fillMaxWidth().padding(10.dp)) {
                        Text(report.verdict, style = MaterialTheme.typography.titleMedium, color = riskColor)
                        Spacer(Modifier.height(4.dp))
                        LinearProgressIndicator(
                            progress = { report.riskScore / 100f },
                            color = riskColor,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Text("Risk Skoru: ${report.riskScore} / 100", style = MaterialTheme.typography.labelSmall)
                    }
                }

                Text("PE Başlık Bilgileri", style = MaterialTheme.typography.titleMedium)
                Text(
                    text = "• Dosya: ${report.fileName} (${formatBytes(report.fileSizeBytes)})\n" +
                        "• Biçim: ${report.peFormat} • Mimari: ${report.architecture}\n" +
                        "• Alt Sistem: ${report.subsystem}\n" +
                        "• Entry Point: ${report.entryPointHex}\n" +
                        "• Derleme Zamanı: ${report.compiledAt}",
                    style = MaterialTheme.typography.labelSmall
                )

                if (report.sections.isNotEmpty()) {
                    Text("PE Bölümleri (${report.sections.size})", style = MaterialTheme.typography.titleMedium)
                    report.sections.forEach { sec ->
                        Text(
                            text = "${sec.name} | Raw: ${sec.rawSize}B | Exec=${sec.isExecutable} Write=${sec.isWritable}",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (sec.isExecutable && sec.isWritable) NovaCrimson else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                if (report.detectedApis.isNotEmpty()) {
                    Text("Tespit Edilen Windows API İmzaları", style = MaterialTheme.typography.titleMedium)
                    Text(
                        text = report.detectedApis.joinToString(", "),
                        style = MaterialTheme.typography.labelSmall,
                        color = NovaAmber
                    )
                }

                if (report.findings.isNotEmpty()) {
                    Text("Güvenlik Bulguları", style = MaterialTheme.typography.titleMedium)
                    report.findings.forEach { f ->
                        Text("• $f", style = MaterialTheme.typography.bodySmall)
                    }
                }

                if (aiNote != null) {
                    Surface(
                        color = NovaAmber.copy(alpha = 0.12f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(aiNote.title, style = MaterialTheme.typography.labelLarge, color = NovaEmerald)
                            Text(aiNote.notice, style = MaterialTheme.typography.labelSmall, color = NovaAmber)
                            Text(aiNote.content, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = onDismiss) { Text("Karantinada Tut / Kapat") }
        }
    )
}

private fun formatBytes(bytes: Long): String {
    if (bytes <= 0) return "0 B"
    val kb = bytes / 1024.0
    val mb = kb / 1024.0
    return when {
        mb >= 1.0 -> String.format("%.2f MB", mb)
        kb >= 1.0 -> String.format("%.1f KB", kb)
        else -> "$bytes B"
    }
}
