package com.beytuweb.app.ui.components

import android.net.Uri
import android.webkit.WebView
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.DesktopWindows
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.beytuweb.app.data.local.HistoryEntity
import com.beytuweb.app.data.prefs.BrowserPreferences
import com.beytuweb.app.system.SystemTelemetry
import com.beytuweb.app.ui.theme.NovaAmber
import com.beytuweb.app.ui.theme.NovaCyan
import com.beytuweb.app.ui.theme.NovaEmerald
import com.beytuweb.app.ui.theme.NovaViolet
import com.beytuweb.app.vpn.VpnState
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun ControlPanelScreen(
    prefs: BrowserPreferences,
    vpnState: VpnState,
    telemetry: SystemTelemetry,
    history: List<HistoryEntity>,
    activeWebViews: Collection<WebView>,
    onBack: () -> Unit,
    onToggleVpn: () -> Unit,
    onSetDarkTheme: (Boolean) -> Unit,
    onSetWebForceDark: (Boolean) -> Unit,
    onSetAdBlock: (Boolean) -> Unit,
    onSetDesktopDefault: (Boolean) -> Unit,
    onSetAiAutoAnswer: (Boolean) -> Unit,
    onSetSearchEngine: (String) -> Unit,
    onSetSyncEmail: (String) -> Unit,
    onOptimizeMemory: (Collection<WebView>) -> Unit,
    onImportChromeRaw: (String) -> Unit,
    onImportSampleChrome: () -> Unit,
    onGenerateBackupJson: suspend () -> String,
    onOpenHistoryUrl: (String) -> Unit,
    onDeleteHistoryItem: (Long) -> Unit,
    onClearHistory: () -> Unit,
    onToast: (String) -> Unit
) {
    BackHandler(onBack = onBack)

    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var emailInput by remember(prefs.syncAccountEmail) { mutableStateOf(prefs.syncAccountEmail) }

    val importDocumentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            val content = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
            if (!content.isNullOrBlank()) {
                onImportChromeRaw(content)
            }
        }
    }

    val exportBackupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                val json = onGenerateBackupJson()
                context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(json) }
                onToast("NovaWeb yedeği başarıyla kaydedildi.")
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Kontrol & Güvenlik Merkezi") },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.minimumInteractiveComponentSize()) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Geri")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter
        ) {
            LazyColumn(
                modifier = Modifier.fillMaxSize().widthIn(max = 720.dp),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // 1. One-Tap VPN Shield
                item {
                    Card(
                        shape = MaterialTheme.shapes.large,
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(
                            1.dp,
                            if (vpnState.isConnected) NovaEmerald else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
                        )
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Filled.VpnKey,
                                contentDescription = null,
                                tint = if (vpnState.isConnected) NovaEmerald else NovaCyan,
                                modifier = Modifier.size(30.dp)
                            )
                            Spacer(Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Tek Tıkla VPN Modu", style = MaterialTheme.typography.titleLarge)
                                Text(
                                    text = if (vpnState.isConnected) {
                                        "${vpnState.statusLabel} • IP: ${vpnState.virtualIp}\nDNS: ${vpnState.dnsProvider}"
                                    } else {
                                        "Şifreli DNS tüneli ile takipçilerden korunun."
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Switch(
                                checked = vpnState.isConnected,
                                onCheckedChange = { onToggleVpn() },
                                modifier = Modifier.testTag("control_vpn_switch")
                            )
                        }
                    }
                }

                // 2. System Resource Monitor & Optimizer
                item {
                    Card(
                        shape = MaterialTheme.shapes.large,
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, NovaCyan.copy(alpha = 0.4f))
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Filled.Memory, contentDescription = null, tint = NovaCyan)
                                    Spacer(Modifier.width(8.dp))
                                    Text("Sistem Kaynak İzleyici", style = MaterialTheme.typography.titleLarge)
                                }
                                Text(
                                    text = "${telemetry.activeTabsCount} Aktif Sekme",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = NovaCyan
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                // Custom Canvas RAM Gauge
                                Box(
                                    modifier = Modifier.size(86.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    val trackColor = MaterialTheme.colorScheme.surfaceVariant
                                    val arcColor = if (telemetry.usedRamPercent > 0.8f) NovaAmber else NovaCyan
                                    Canvas(modifier = Modifier.fillMaxSize()) {
                                        drawArc(
                                            color = trackColor,
                                            startAngle = -220f,
                                            sweepAngle = 260f,
                                            useCenter = false,
                                            style = Stroke(width = 10.dp.toPx(), cap = StrokeCap.Round)
                                        )
                                        drawArc(
                                            color = arcColor,
                                            startAngle = -220f,
                                            sweepAngle = 260f * telemetry.usedRamPercent,
                                            useCenter = false,
                                            style = Stroke(width = 10.dp.toPx(), cap = StrokeCap.Round)
                                        )
                                    }
                                    Text(
                                        text = "${(telemetry.usedRamPercent * 100).toInt()}%",
                                        style = MaterialTheme.typography.titleMedium
                                    )
                                }

                                Column(
                                    modifier = Modifier.weight(1f),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text(
                                        "Boş RAM: ${telemetry.availableRamMb} / ${telemetry.totalRamMb} MB",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                    Text(
                                        "Uygulama Heap: ${String.format("%.1f", telemetry.appHeapMb)} MB • Native: ${String.format("%.1f", telemetry.nativeHeapMb)} MB",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        "Önbellek: ${String.format("%.2f", telemetry.webCacheMb)} MB",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        "Ağ: ↓${String.format("%.1f", telemetry.networkRxMb)} MB / ↑${String.format("%.1f", telemetry.networkTxMb)} MB",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = NovaEmerald
                                    )
                                }
                            }

                            Button(
                                onClick = { onOptimizeMemory(activeWebViews) },
                                modifier = Modifier.fillMaxWidth().testTag("optimize_memory_button")
                            ) {
                                Icon(Icons.Filled.CleaningServices, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(8.dp))
                                Text("Belleği ve Önbelleği Optimize Et")
                            }
                        }
                    }
                }

                // 3. Privacy, Theme & Browser Settings
                item {
                    Card(
                        shape = MaterialTheme.shapes.large,
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text("Gizlilik, Görünüm ve Yapay Zeka", style = MaterialTheme.typography.titleLarge)

                            SettingToggleRow(
                                icon = Icons.Filled.Shield,
                                title = "Reklam & İzleyici Engelleyici",
                                subtitle = "${prefs.adsBlockedCount} reklam/izleyici engellendi",
                                checked = prefs.adBlockEnabled,
                                onCheckedChange = onSetAdBlock,
                                testTag = "toggle_adblock"
                            )
                            SettingToggleRow(
                                icon = Icons.Filled.DarkMode,
                                title = "Uygulama Koyu Teması",
                                subtitle = "Obsidian gece arayüzü",
                                checked = prefs.darkThemeEnabled,
                                onCheckedChange = onSetDarkTheme,
                                testTag = "toggle_dark_theme"
                            )
                            SettingToggleRow(
                                icon = Icons.Filled.DarkMode,
                                title = "Web Sayfaları Karanlık Modu",
                                subtitle = "Web sitelerini otomatik karanlık temaya uyarlar",
                                checked = prefs.webForceDarkEnabled,
                                onCheckedChange = onSetWebForceDark,
                                testTag = "toggle_web_dark"
                            )
                            SettingToggleRow(
                                icon = Icons.Filled.AutoAwesome,
                                title = "Aramada Otomatik Yapay Zeka Yanıtı",
                                subtitle = "Arama yaparken AI özet kartını gösterir",
                                checked = prefs.aiAutoAnswerEnabled,
                                onCheckedChange = onSetAiAutoAnswer,
                                testTag = "toggle_ai_auto"
                            )
                            SettingToggleRow(
                                icon = Icons.Filled.DesktopWindows,
                                title = "Varsayılan Masaüstü Modu",
                                subtitle = "Yeni sekmeleri masaüstü görünümünde açar",
                                checked = prefs.desktopModeDefault,
                                onCheckedChange = onSetDesktopDefault,
                                testTag = "toggle_desktop_default"
                            )

                            Text("Varsayılan Arama Motoru", style = MaterialTheme.typography.titleMedium)
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf("Google", "DuckDuckGo", "Bing").forEach { eng ->
                                    FilterChip(
                                        selected = prefs.searchEngine == eng,
                                        onClick = { onSetSearchEngine(eng) },
                                        label = { Text(eng) }
                                    )
                                }
                            }
                        }
                    }
                }

                // 4. Chrome/Google Data Import, Backup & Cloud Sync
                item {
                    Card(
                        shape = MaterialTheme.shapes.large,
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, NovaViolet.copy(alpha = 0.45f))
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.CloudSync, contentDescription = null, tint = NovaViolet)
                                Spacer(Modifier.width(8.dp))
                                Text("Chrome Veri Aktarımı, Yedek & Bulut", style = MaterialTheme.typography.titleLarge)
                            }

                            Surface(
                                color = NovaAmber.copy(alpha = 0.14f),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Filled.Info, contentDescription = null, tint = NovaAmber, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(8.dp))
                                    Text(
                                        text = "Bulut senkronizasyonu (Google/Firestore) şu an yerel yedekleme modundadır; cihazlar arası otomatik bulut senkronizasyonu için Firebase kurulumu etkinleştirilmelidir.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = NovaAmber
                                    )
                                }
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedTextField(
                                    value = emailInput,
                                    onValueChange = { emailInput = it },
                                    label = { Text("Gmail / Google Hesabı") },
                                    singleLine = true,
                                    modifier = Modifier.weight(1f)
                                )
                                OutlinedButton(onClick = {
                                    onSetSyncEmail(emailInput)
                                    onToast("Hesap profili güncellendi: $emailInput")
                                }) {
                                    Text("Kaydet")
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = { importDocumentLauncher.launch(arrayOf("text/html", "application/json", "*/*")) },
                                    modifier = Modifier.weight(1f).testTag("import_chrome_file_button")
                                ) {
                                    Icon(Icons.Filled.UploadFile, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Chrome HTML/JSON Aktar")
                                }
                                OutlinedButton(
                                    onClick = onImportSampleChrome,
                                    modifier = Modifier.testTag("import_sample_chrome_button")
                                ) {
                                    Text("Örnek Yükle")
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = { exportBackupLauncher.launch("novaweb_yedek.json") },
                                    modifier = Modifier.weight(1f).testTag("export_backup_button")
                                ) {
                                    Icon(Icons.Filled.Backup, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Yedeği Dışa Aktar")
                                }
                                OutlinedButton(
                                    onClick = { importDocumentLauncher.launch(arrayOf("application/json", "*/*")) },
                                    modifier = Modifier.weight(1f).testTag("restore_backup_button")
                                ) {
                                    Icon(Icons.Filled.Restore, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Yedekten Geri Yükle")
                                }
                            }

                            if (prefs.lastBackupTimestamp > 0L) {
                                val fmt = SimpleDateFormat("dd MMM yyyy HH:mm", Locale.getDefault()).format(Date(prefs.lastBackupTimestamp))
                                Text(
                                    text = "Son yedekleme: $fmt",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = NovaEmerald
                                )
                            }
                        }
                    }
                }

                // 5. History Section (Normal tabs only)
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.History, contentDescription = null, tint = NovaCyan)
                            Spacer(Modifier.width(8.dp))
                            Column {
                                Text("Tarama Geçmişi (${history.size})", style = MaterialTheme.typography.titleLarge)
                                Text(
                                    "Gizli mod ziyaretleri buraya asla kaydedilmez",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = NovaViolet
                                )
                            }
                        }
                        if (history.isNotEmpty()) {
                            TextButton(onClick = onClearHistory) {
                                Icon(Icons.Filled.DeleteSweep, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Temizle", color = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }

                items(history.take(30), key = { it.id }) { h ->
                    Surface(
                        shape = MaterialTheme.shapes.small,
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onOpenHistoryUrl(h.url) }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(h.title, style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(h.url, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            IconButton(onClick = { onDeleteHistoryItem(h.id) }, modifier = Modifier.minimumInteractiveComponentSize()) {
                                Icon(Icons.Filled.Delete, contentDescription = "Geçmiş kaydını sil", modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingToggleRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    testTag: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            modifier = Modifier.testTag(testTag)
        )
    }
}
