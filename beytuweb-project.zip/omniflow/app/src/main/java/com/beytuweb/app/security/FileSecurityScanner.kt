package com.beytuweb.app.security

import com.beytuweb.app.data.local.ScanStatus
import java.io.File
import java.io.FileInputStream
import java.security.MessageDigest
import kotlin.math.log2

data class FileScanResult(
    val status: ScanStatus,
    val riskScore: Int,
    val sha256: String,
    val entropy: Double,
    val detectedMagicType: String,
    val summary: String,
    val findings: List<String>,
    val isExecutable: Boolean
)

object FileSecurityScanner {

    fun categorizeFile(fileName: String, mimeType: String?): String {
        val ext = fileName.substringAfterLast('.', "").lowercase()
        val mime = mimeType?.lowercase().orEmpty()

        return when {
            ext in listOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "svg", "heic") ||
                mime.startsWith("image/") -> "Görseller"

            ext in listOf("mp4", "mkv", "webm", "mov", "avi", "m4v", "3gp") ||
                mime.startsWith("video/") -> "Videolar"

            ext in listOf("mp3", "wav", "ogg", "m4a", "flac", "aac", "opus") ||
                mime.startsWith("audio/") -> "Ses"

            ext in listOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "csv", "json", "html", "xml", "md") ||
                mime.startsWith("text/") || mime == "application/pdf" -> "Belgeler"

            ext in listOf("zip", "rar", "7z", "tar", "gz", "bz2", "xz") ||
                mime.contains("zip") || mime.contains("archive") -> "Arşivler"

            ext in listOf("exe", "msi", "dll", "apk", "bat", "cmd", "ps1", "sh", "elf") -> "Çalıştırılabilir"

            else -> "Diğer"
        }
    }

    fun scanFile(file: File, sourceUrl: String): FileScanResult {
        if (!file.exists() || !file.isFile) {
            return FileScanResult(
                status = ScanStatus.SUSPICIOUS,
                riskScore = 40,
                sha256 = "",
                entropy = 0.0,
                detectedMagicType = "Bilinmiyor",
                summary = "Dosya diskte bulunamadı",
                findings = listOf("Dosya doğrulama için erişilemedi."),
                isExecutable = false
            )
        }

        val sha256 = computeSha256(file)
        val header = ByteArray(16)
        val headerRead = FileInputStream(file).use { it.read(header) }
        val magicType = detectMagicType(header, headerRead)
        val entropy = computeSampleEntropy(file)
        val ext = file.name.substringAfterLast('.', "").lowercase()
        val isExe = ext in listOf("exe", "msi", "dll", "bat") || magicType.startsWith("PE/MZ")

        val findings = mutableListOf<String>()
        var riskScore = 0

        if (magicType.startsWith("PE/MZ") && ext !in listOf("exe", "dll", "msi", "sys")) {
            riskScore += 55
            findings += "Uzantı Sahteciliği: Dosya .$ext uzantılı görünüyor ancak gerçek başlık Windows PE/EXE (MZ)."
        }

        if (isExe) {
            riskScore += 25
            findings += "Çalıştırılabilir ikili dosya ($magicType). Açmadan önce Sandbox Analizi önerilir."
        }

        if (entropy > 7.45) {
            riskScore += 20
            findings += "Yüksek entropi (${String.format("%.2f", entropy)} bit/bayt): Paketlenmiş veya şifrelenmiş içerik olabilir."
        } else if (entropy > 6.8 && isExe) {
            riskScore += 10
            findings += "Orta-yüksek entropi (${String.format("%.2f", entropy)} bit/bayt)."
        }

        val lowerUrl = sourceUrl.lowercase()
        if (lowerUrl.startsWith("http://")) {
            riskScore += 10
            findings += "Şifresiz HTTP bağlantısı üzerinden indirildi."
        }
        if (listOf("crack", "keygen", "payload", "trojan", "cheat").any { lowerUrl.contains(it) }) {
            riskScore += 35
            findings += "Kaynak URL yüksek riskli anahtar kelimeler içeriyor."
        }

        riskScore = riskScore.coerceIn(0, 100)
        val status = when {
            riskScore >= 60 -> ScanStatus.THREAT
            riskScore >= 25 -> ScanStatus.SUSPICIOUS
            else -> ScanStatus.CLEAN
        }

        val summary = when (status) {
            ScanStatus.CLEAN -> "Temiz • $magicType • Entropi ${String.format("%.2f", entropy)}"
            ScanStatus.SUSPICIOUS -> "Dikkat ($riskScore/100) • $magicType"
            ScanStatus.THREAT -> "Tehdit Algılandı ($riskScore/100) • $magicType"
            else -> "Tarama tamamlandı"
        }

        return FileScanResult(
            status = status,
            riskScore = riskScore,
            sha256 = sha256,
            entropy = entropy,
            detectedMagicType = magicType,
            summary = summary,
            findings = findings,
            isExecutable = isExe
        )
    }

    private fun computeSha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val buffer = ByteArray(8192)
        FileInputStream(file).use { input ->
            var read = input.read(buffer)
            while (read > 0) {
                digest.update(buffer, 0, read)
                read = input.read(buffer)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun computeSampleEntropy(file: File): Double {
        val counts = IntArray(256)
        val maxSample = 262_144
        val buffer = ByteArray(8192)
        var total = 0
        FileInputStream(file).use { input ->
            while (total < maxSample) {
                val read = input.read(buffer)
                if (read <= 0) break
                for (i in 0 until read) {
                    counts[buffer[i].toInt() and 0xFF]++
                }
                total += read
            }
        }
        if (total == 0) return 0.0
        var entropy = 0.0
        for (c in counts) {
            if (c > 0) {
                val p = c.toDouble() / total
                entropy -= p * log2(p)
            }
        }
        return entropy
    }

    private fun detectMagicType(h: ByteArray, len: Int): String {
        if (len < 2) return "Bilinmiyor"
        if (h[0] == 0x4D.toByte() && h[1] == 0x5A.toByte()) return "PE/MZ Çalıştırılabilir"
        if (len >= 4 && h[0] == 0x7F.toByte() && h[1] == 0x45.toByte() && h[2] == 0x4C.toByte() && h[3] == 0x46.toByte()) return "ELF Binary"
        if (len >= 4 && h[0] == 0x25.toByte() && h[1] == 0x50.toByte() && h[2] == 0x44.toByte() && h[3] == 0x46.toByte()) return "PDF Belgesi"
        if (len >= 4 && h[0] == 0x50.toByte() && h[1] == 0x4B.toByte() && h[2] == 0x03.toByte() && h[3] == 0x04.toByte()) return "ZIP / APK Arşivi"
        if (len >= 4 && h[0] == 0x89.toByte() && h[1] == 0x50.toByte() && h[2] == 0x4E.toByte() && h[3] == 0x47.toByte()) return "PNG Görsel"
        if (len >= 3 && h[0] == 0xFF.toByte() && h[1] == 0xD8.toByte() && h[2] == 0xFF.toByte()) return "JPEG Görsel"
        if (len >= 8 && h[4] == 0x66.toByte() && h[5] == 0x74.toByte() && h[6] == 0x79.toByte() && h[7] == 0x70.toByte()) return "MP4 Video"
        if (len >= 3 && h[0] == 0x49.toByte() && h[1] == 0x44.toByte() && h[2] == 0x33.toByte()) return "MP3 Ses"
        return "Veri / Metin"
    }
}
