package com.beytuweb.app.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val NovaDarkColorScheme = darkColorScheme(
    primary = NovaCyan,
    onPrimary = NovaObsidian,
    primaryContainer = NovaCyanMuted,
    onPrimaryContainer = NovaTextPrimary,
    secondary = NovaEmerald,
    onSecondary = NovaObsidian,
    secondaryContainer = NovaEmeraldMuted,
    onSecondaryContainer = NovaTextPrimary,
    tertiary = NovaViolet,
    onTertiary = Color.White,
    background = NovaObsidian,
    onBackground = NovaTextPrimary,
    surface = NovaSurface,
    onSurface = NovaTextPrimary,
    surfaceVariant = NovaSurfaceVariant,
    onSurfaceVariant = NovaTextSecondary,
    surfaceContainerHigh = NovaSurfaceElevated,
    outline = NovaOutline,
    error = NovaCrimson,
    onError = Color.White
)

private val NovaIncognitoColorScheme = darkColorScheme(
    primary = NovaViolet,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF4C1D95),
    onPrimaryContainer = Color(0xFFF3E8FF),
    secondary = NovaCyan,
    onSecondary = NovaObsidian,
    background = Color(0xFF0D0916),
    onBackground = NovaTextPrimary,
    surface = NovaVioletSurface,
    onSurface = NovaTextPrimary,
    surfaceVariant = Color(0xFF281B3D),
    onSurfaceVariant = Color(0xFFC4B5FD),
    surfaceContainerHigh = Color(0xFF32224B),
    outline = Color(0xFF4C3575),
    error = NovaCrimson,
    onError = Color.White
)

private val NovaLightColorScheme = lightColorScheme(
    primary = NovaLightPrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE0F2FE),
    onPrimaryContainer = Color(0xFF0C4A6E),
    secondary = NovaEmerald,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFD1FAE5),
    onSecondaryContainer = Color(0xFF064E3B),
    tertiary = NovaViolet,
    onTertiary = Color.White,
    background = NovaLightBg,
    onBackground = NovaLightTextPrimary,
    surface = NovaLightSurface,
    onSurface = NovaLightTextPrimary,
    surfaceVariant = NovaLightSurfaceVariant,
    onSurfaceVariant = NovaLightTextSecondary,
    outline = NovaLightOutline,
    error = NovaCrimson,
    onError = Color.White
)

val NovaShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(30.dp)
)

@Composable
fun NovaWebTheme(
    darkTheme: Boolean = true,
    isIncognito: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        isIncognito -> NovaIncognitoColorScheme
        darkTheme -> NovaDarkColorScheme
        else -> NovaLightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = NovaTypography,
        shapes = NovaShapes,
        content = content
    )
}
