package com.beytuweb.app.security

import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream
import java.net.URI

object AdBlockerEngine {

    private val blockedHosts = hashSetOf(
        "doubleclick.net",
        "googlesyndication.com",
        "googleadservices.com",
        "adservice.google.com",
        "adservice.google.com.tr",
        "pagead2.googlesyndication.com",
        "tpc.googlesyndication.com",
        "adclick.g.doubleclick.net",
        "google-analytics.com",
        "www.google-analytics.com",
        "ssl.google-analytics.com",
        "ads.tiktok.com",
        "analytics.tiktok.com",
        "ads-api.tiktok.com",
        "business-api.tiktok.com",
        "connect.facebook.net",
        "an.facebook.com",
        "pixel.facebook.com",
        "ads.youtube.com",
        "taboola.com",
        "cdn.taboola.com",
        "outbrain.com",
        "widgets.outbrain.com",
        "criteo.com",
        "static.criteo.net",
        "pubmatic.com",
        "adnxs.com",
        "rubiconproject.com",
        "openx.net",
        "amazon-adsystem.com",
        "scorecardresearch.com",
        "quantserve.com",
        "hotjar.com",
        "clarity.ms",
        "ads.twitter.com",
        "analytics.twitter.com",
        "ads.yahoo.com",
        "gemini.yahoo.com",
        "mgid.com",
        "propellerads.com",
        "popads.net",
        "adsterra.com",
        "yandexadexchange.net"
    )

    private val blockedPathTokens = listOf(
        "/pagead/",
        "/adserver/",
        "/ad_status",
        "/ptracking",
        "/api/stats/ads",
        "/doubleclick/"
    )

    fun isAdRequest(url: String?): Boolean {
        if (url.isNullOrBlank()) return false
        val host = try {
            URI(url).host?.lowercase()
        } catch (_: Exception) {
            null
        } ?: return false

        // Exact or subdomain match against blockedHosts
        var candidate = host
        while (candidate.contains('.')) {
            if (blockedHosts.contains(candidate)) return true
            val dot = candidate.indexOf('.')
            if (dot < 0 || dot + 1 >= candidate.length) break
            candidate = candidate.substring(dot + 1)
        }

        val lowerUrl = url.lowercase()
        return blockedPathTokens.any { lowerUrl.contains(it) }
    }

    fun createEmptyAdResponse(): WebResourceResponse {
        return WebResourceResponse(
            "text/plain",
            "utf-8",
            ByteArrayInputStream(ByteArray(0))
        )
    }

    const val COSMETIC_AD_HIDE_JS = """
        (function() {
            try {
                if (document.getElementById('nova-adblock-style')) return;
                var style = document.createElement('style');
                style.id = 'nova-adblock-style';
                style.innerHTML = [
                    'ins.adsbygoogle',
                    '[id^="google_ads_iframe"]',
                    '[class*="ad-banner"]',
                    '[class*="sponsored-ad"]',
                    '[data-ad-slot]',
                    'ytd-promoted-sparkles-web-renderer',
                    'ytm-promoted-sparkles-web-renderer',
                    '.ytp-ad-overlay-container',
                    '.ad-showing .ytp-ad-skip-button-slot'
                ].join(',') + '{ display: none !important; visibility: hidden !important; height: 0 !important; }';
                (document.head || document.documentElement).appendChild(style);
            } catch(e) {}
        })();
    """
}
