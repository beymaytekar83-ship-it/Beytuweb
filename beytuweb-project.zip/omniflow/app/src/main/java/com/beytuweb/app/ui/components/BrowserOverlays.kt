package com.beytuweb.app.ui.components

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.beytuweb.app.ui.AiUiState
import com.beytuweb.app.ui.BrowserTab
import com.beytuweb.app.ui.theme.NovaAmber
import com.beytuweb.app.ui.theme.NovaCyan
import com.beytuweb.app.ui.theme.NovaEmerald
import com.beytuweb.app.ui.theme.NovaViolet

@Composable
fun AiSearchAnswerCard(
    aiState: AiUiState,
    onDismiss: () -> Unit,
    onAskFollowUp: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    AnimatedVisibility(visible = aiState !is AiUiState.Idle, modifier = modifier) {
        var expanded by remember { mutableStateOf(true) }
        var followUp by remember { mutableStateOf("") }

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            shape = MaterialTheme.shapes.medium,
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, NovaEmerald.copy(alpha = 0.55f))
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .weight(1f)
                            .clickable { expanded = !expanded }
                    ) {
                        Icon(
                            imageVector = Icons.Filled.AutoAwesome,
                            contentDescription = null,
                            tint = NovaEmerald,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = when (aiState) {
                                is AiUiState.Loading -> "Yapay Zeka Yanıt Hazırlıyor..."
                                is AiUiState.Success -> aiState.response.title
                                is AiUiState.Error -> "AI Hatası"
                                else -> "NovaWeb AI"
                            },
                            style = MaterialTheme.typography.titleMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(32.dp).testTag("dismiss_ai_card")
                    ) {
                        Icon(Icons.Filled.Close, contentDescription = "AI kartını kapat", modifier = Modifier.size(18.dp))
                    }
                }

                if (expanded) {
                    Spacer(Modifier.height(8.dp))
                    when (aiState) {
                        is AiUiState.Loading -> {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                                Spacer(Modifier.width(10.dp))
                                Text("Sorgunuz analiz ediliyor...", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        is AiUiState.Success -> {
                            if (aiState.response.isPlaceholder) {
                                Surface(
                                    color = NovaAmber.copy(alpha = 0.15f),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Filled.Info, contentDescription = null, tint = NovaAmber, modifier = Modifier.size(15.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text(
                                            text = aiState.response.notice,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = NovaAmber
                                        )
                                    }
                                }
                            }
                            Text(
                                text = aiState.response.content,
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.heightIn(max = 180.dp).verticalScroll(rememberScrollState())
                            )
                            Spacer(Modifier.height(8.dp))
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedTextField(
                                    value = followUp,
                                    onValueChange = { followUp = it },
                                    placeholder = { Text("Yapay zekaya devam sorusu sor...") },
                                    singleLine = true,
                                    modifier = Modifier.weight(1f)
                                )
                                IconButton(
                                    onClick = {
                                        if (followUp.isNotBlank()) {
                                            onAskFollowUp(followUp)
                                            followUp = ""
                                        }
                                    },
                                    modifier = Modifier.minimumInteractiveComponentSize()
                                ) {
                                    Icon(Icons.Filled.Send, contentDescription = "Gönder", tint = NovaCyan)
                                }
                            }
                        }
                        is AiUiState.Error -> {
                            Text(
                                text = aiState.message,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                        else -> Unit
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TabsSwitcherSheet(
    tabs: List<BrowserTab>,
    activeTabId: String,
    onSelectTab: (String) -> Unit,
    onCloseTab: (String) -> Unit,
    onNewTab: (Boolean) -> Unit,
    onCloseAllIncognito: () -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Açık Sekmeler (${tabs.size})", style = MaterialTheme.typography.headlineSmall)
                if (tabs.any { it.isIncognito }) {
                    TextButton(onClick = onCloseAllIncognito) {
                        Icon(Icons.Filled.DeleteSweep, contentDescription = null, tint = NovaViolet, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Gizlileri Kapat", color = NovaViolet)
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = {
                        onNewTab(false)
                        onDismiss()
                    },
                    modifier = Modifier.weight(1f).testTag("new_normal_tab_button")
                ) {
                    Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Yeni Sekme")
                }
                OutlinedButton(
                    onClick = {
                        onNewTab(true)
                        onDismiss()
                    },
                    modifier = Modifier.weight(1f).testTag("new_incognito_tab_button")
                ) {
                    Icon(Icons.Filled.VisibilityOff, contentDescription = null, tint = NovaViolet, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Gizli Mod", color = NovaViolet)
                }
            }

            LazyColumn(
                modifier = Modifier.heightIn(max = 360.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(tabs, key = { it.id }) { tab ->
                    val isActive = tab.id == activeTabId
                    val borderColor = when {
                        isActive && tab.isIncognito -> NovaViolet
                        isActive -> NovaCyan
                        tab.isIncognito -> NovaViolet.copy(alpha = 0.4f)
                        else -> MaterialTheme.colorScheme.outline.copy(alpha = 0.45f)
                    }
                    Surface(
                        shape = MaterialTheme.shapes.medium,
                        color = if (tab.isIncognito) Color(0xFF1D132B) else MaterialTheme.colorScheme.surfaceVariant,
                        border = BorderStroke(if (isActive) 2.dp else 1.dp, borderColor),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(MaterialTheme.shapes.medium)
                            .clickable {
                                onSelectTab(tab.id)
                                onDismiss()
                            }
                            .testTag("tab_item_${tab.id}")
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (tab.isIncognito) Icons.Filled.VisibilityOff else Icons.Filled.Public,
                                contentDescription = null,
                                tint = if (tab.isIncognito) NovaViolet else NovaCyan
                            )
                            Spacer(Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = tab.title.ifBlank { "Yeni Sekme" },
                                    style = MaterialTheme.typography.titleMedium,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = if (tab.isHome) "Başlangıç Sayfası" else tab.url,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            IconButton(
                                onClick = { onCloseTab(tab.id) },
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("close_tab_${tab.id}")
                            ) {
                                Icon(Icons.Filled.Close, contentDescription = "Sekmeyi kapat")
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PageTranslatorDialog(
    currentLang: String,
    translationState: AiUiState,
    onTranslateRequest: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var selectedLang by remember { mutableStateOf(currentLang) }
    val languages = listOf("Türkçe", "English", "Deutsch", "Español", "Français", "العربية")

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Filled.Translate, contentDescription = null, tint = NovaCyan) },
        title = { Text("Tarayıcı İçi Sayfa Çevirisi") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Hedef dili seçin:", style = MaterialTheme.typography.labelLarge)
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    languages.forEach { lang ->
                        FilterChip(
                            selected = selectedLang == lang,
                            onClick = { selectedLang = lang },
                            label = { Text(lang) }
                        )
                    }
                }
                when (translationState) {
                    is AiUiState.Loading -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                            Spacer(Modifier.width(8.dp))
                            Text("Sayfa içeriği çevriliyor...")
                        }
                    }
                    is AiUiState.Success -> {
                        Surface(
                            color = NovaAmber.copy(alpha = 0.14f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = translationState.response.notice,
                                style = MaterialTheme.typography.bodySmall,
                                color = NovaAmber,
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                        Text(
                            text = translationState.response.content,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.heightIn(max = 200.dp).verticalScroll(rememberScrollState())
                        )
                    }
                    is AiUiState.Error -> {
                        Text(translationState.message, color = MaterialTheme.colorScheme.error)
                    }
                    else -> {
                        Text(
                            "Aktif sekmedeki metin okunup seçtiğiniz dile çevrilecektir.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onTranslateRequest(selectedLang) },
                modifier = Modifier.testTag("run_translate_button")
            ) {
                Icon(Icons.Filled.Language, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("Çevir")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Kapat") }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun VoiceCommandSheet(
    onCommandRecognized: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var manualInput by remember { mutableStateOf("") }
    var isListening by remember { mutableStateOf(false) }
    var voiceStatus by remember { mutableStateOf("Mikrofona dokunun veya hızlı komut seçin") }

    val speechRecognizer = remember {
        if (SpeechRecognizer.isRecognitionAvailable(context)) {
            SpeechRecognizer.createSpeechRecognizer(context)
        } else null
    }

    val startNativeRecognition = {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                isListening = true
                voiceStatus = "Dinleniyor... Komutunuzu söyleyin"
            }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { isListening = false }
            override fun onError(error: Int) {
                isListening = false
                voiceStatus = "Ses algılanamadı (kod $error). Aşağıdan yazabilir veya hazır komut seçebilirsiniz."
            }
            override fun onResults(results: Bundle?) {
                isListening = false
                val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!spoken.isNullOrBlank()) {
                    onCommandRecognized(spoken)
                    onDismiss()
                }
            }
            override fun onPartialResults(partialResults: Bundle?) {
                val partial = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!partial.isNullOrBlank()) manualInput = partial
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        speechRecognizer?.startListening(intent)
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            startNativeRecognition()
        } else {
            voiceStatus = "Mikrofon izni reddedildi. Komutu yazabilir veya hazır komut seçebilirsiniz."
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            speechRecognizer?.destroy()
        }
    }

    val quickVoiceCommands = listOf(
        "YouTube aç",
        "TikTok aç",
        "Gizli mod",
        "VPN aç",
        "Reklam engelleyici",
        "Sayfayı çevir",
        "İndirilenler",
        "Kontrol paneli"
    )

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Sesli Komut Kontrolü", style = MaterialTheme.typography.headlineSmall)
            Text(
                text = voiceStatus,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Box(
                modifier = Modifier
                    .size(72.dp)
                    .clip(CircleShape)
                    .background(if (isListening) NovaEmerald.copy(alpha = 0.25f) else NovaCyan.copy(alpha = 0.18f))
                    .clickable {
                        if (speechRecognizer == null) {
                            voiceStatus = "Bu cihazda sistem ses tanıma servisi yok; komutu yazın veya aşağıdan seçin."
                        } else if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                            startNativeRecognition()
                        } else {
                            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    }
                    .testTag("mic_listen_button"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.Mic,
                    contentDescription = "Sesli komut başlat",
                    tint = if (isListening) NovaEmerald else NovaCyan,
                    modifier = Modifier.size(34.dp)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = manualInput,
                    onValueChange = { manualInput = it },
                    placeholder = { Text("Veya sesli komut yazın...") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                Button(
                    onClick = {
                        if (manualInput.isNotBlank()) {
                            onCommandRecognized(manualInput)
                            onDismiss()
                        }
                    }
                ) { Text("Çalıştır") }
            }

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                quickVoiceCommands.forEach { cmd ->
                    AssistChip(
                        onClick = {
                            onCommandRecognized(cmd)
                            onDismiss()
                        },
                        label = { Text(cmd) }
                    )
                }
            }
        }
    }
}
