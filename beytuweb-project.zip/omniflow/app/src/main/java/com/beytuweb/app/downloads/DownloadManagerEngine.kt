package com.beytuweb.app.downloads

import android.content.Context
import android.webkit.MimeTypeMap
import android.webkit.URLUtil
import com.beytuweb.app.data.local.DownloadEntity
import com.beytuweb.app.data.local.DownloadStatus
import com.beytuweb.app.data.local.NovaDao
import com.beytuweb.app.data.local.ScanStatus
import com.beytuweb.app.security.ExeSandboxAnalyzer
import com.beytuweb.app.security.FileSecurityScanner
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

class DownloadManagerEngine(
    private val context: Context,
    private val dao: NovaDao
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val activeJobs = ConcurrentHashMap<Long, Job>()

    private val client = OkHttpClient.Builder()
        .connectTimeout(25, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    fun enqueueDownload(
        url: String,
        suggestedFileName: String? = null,
        mimeType: String? = null
    ) {
        scope.launch {
            val cleanUrl = url.trim()
            if (cleanUrl.isBlank()) return@launch

            val rawName = suggestedFileName?.takeIf { it.isNotBlank() }
                ?: URLUtil.guessFileName(cleanUrl, null, mimeType)
            val safeName = rawName.replace(Regex("[^a-zA-Z0-9._-]"), "_")
            val resolvedMime = mimeType ?: guessMimeFromName(safeName)
            val category = FileSecurityScanner.categorizeFile(safeName, resolvedMime)

            val categoryDir = File(File(context.filesDir, "Downloads"), category)
            if (!categoryDir.exists()) categoryDir.mkdirs()

            val targetFile = uniqueFile(categoryDir, safeName)
            val isExe = category == "Çalıştırılabilir" || safeName.lowercase().endsWith(".exe")

            val id = dao.insertDownload(
                DownloadEntity(
                    fileName = targetFile.name,
                    url = cleanUrl,
                    category = category,
                    filePath = targetFile.absolutePath,
                    mimeType = resolvedMime,
                    status = DownloadStatus.QUEUED.name,
                    scanStatus = ScanStatus.PENDING.name,
                    isExecutable = isExe
                )
            )
            startOrResume(id)
        }
    }

    fun startOrResume(downloadId: Long) {
        if (activeJobs[downloadId]?.isActive == true) return

        val job = scope.launch {
            val entity = dao.getDownloadById(downloadId) ?: return@launch
            val partFile = File("${entity.filePath}.part")
            val finalFile = File(entity.filePath)
            finalFile.parentFile?.mkdirs()

            val existingBytes = if (partFile.exists()) partFile.length() else 0L
            dao.updateDownload(
                entity.copy(
                    status = DownloadStatus.DOWNLOADING.name,
                    downloadedBytes = existingBytes
                )
            )
            notifyForeground(entity.fileName, 0)

            try {
                val requestBuilder = Request.Builder()
                    .url(entity.url)
                    .header("User-Agent", "Mozilla/5.0 (Linux; Android 14) NovaWeb/1.0")
                if (existingBytes > 0L) {
                    requestBuilder.header("Range", "bytes=$existingBytes-")
                }

                client.newCall(requestBuilder.build()).execute().use { response ->
                    if (!response.isSuccessful && response.code != 206) {
                        dao.updateDownload(
                            entity.copy(
                                status = DownloadStatus.FAILED.name,
                                scanSummary = "HTTP ${response.code} hatası"
                            )
                        )
                        return@use
                    }

                    val body = response.body ?: throw IllegalStateException("Boş yanıt")
                    val supportsResume = response.code == 206
                    val offset = if (supportsResume) existingBytes else 0L
                    val contentLen = body.contentLength()
                    val totalBytes = if (contentLen > 0) offset + contentLen else entity.totalBytes

                    var downloaded = offset
                    var lastProgressUpdate = 0L

                    FileOutputStream(partFile, supportsResume).use { output ->
                        body.byteStream().use { input ->
                            val buffer = ByteArray(16 * 1024)
                            while (true) {
                                val read = input.read(buffer)
                                if (read == -1) break
                                output.write(buffer, 0, read)
                                downloaded += read

                                val now = System.currentTimeMillis()
                                if (now - lastProgressUpdate > 250L) {
                                    lastProgressUpdate = now
                                    val pct = if (totalBytes > 0) ((downloaded * 100) / totalBytes).toInt() else -1
                                    dao.updateDownload(
                                        entity.copy(
                                            status = DownloadStatus.DOWNLOADING.name,
                                            downloadedBytes = downloaded,
                                            totalBytes = totalBytes
                                        )
                                    )
                                    notifyForeground(entity.fileName, pct)
                                }
                            }
                        }
                    }

                    if (finalFile.exists()) finalFile.delete()
                    partFile.renameTo(finalFile)

                    val scanningState = entity.copy(
                        status = DownloadStatus.COMPLETED.name,
                        downloadedBytes = finalFile.length(),
                        totalBytes = finalFile.length(),
                        scanStatus = ScanStatus.SCANNING.name,
                        scanSummary = "Antivirüs taraması yapılıyor..."
                    )
                    dao.updateDownload(scanningState)

                    val scanResult = FileSecurityScanner.scanFile(finalFile, entity.url)
                    val sandboxReport = if (scanResult.isExecutable) {
                        val rep = ExeSandboxAnalyzer.inspect(finalFile)
                        "${rep.peFormat} • ${rep.architecture} • ${rep.verdict}"
                    } else ""

                    dao.updateDownload(
                        scanningState.copy(
                            scanStatus = scanResult.status.name,
                            scanRiskScore = scanResult.riskScore,
                            scanSummary = scanResult.summary,
                            sha256 = scanResult.sha256,
                            isExecutable = scanResult.isExecutable,
                            sandboxSummary = sandboxReport
                        )
                    )
                }
            } catch (e: CancellationException) {
                val latest = dao.getDownloadById(downloadId)
                if (latest != null && latest.status == DownloadStatus.DOWNLOADING.name) {
                    val saved = if (partFile.exists()) partFile.length() else latest.downloadedBytes
                    dao.updateDownload(
                        latest.copy(
                            status = DownloadStatus.PAUSED.name,
                            downloadedBytes = saved
                        )
                    )
                }
                throw e
            } catch (e: Exception) {
                val latest = dao.getDownloadById(downloadId) ?: entity
                val saved = if (partFile.exists()) partFile.length() else latest.downloadedBytes
                dao.updateDownload(
                    latest.copy(
                        status = DownloadStatus.FAILED.name,
                        downloadedBytes = saved,
                        scanSummary = "Hata: ${e.localizedMessage ?: "Bağlantı kesildi"}"
                    )
                )
            } finally {
                activeJobs.remove(downloadId)
                refreshForegroundService()
            }
        }
        activeJobs[downloadId] = job
    }

    fun pauseDownload(downloadId: Long) {
        scope.launch {
            val entity = dao.getDownloadById(downloadId) ?: return@launch
            val partFile = File("${entity.filePath}.part")
            val currentBytes = if (partFile.exists()) partFile.length() else entity.downloadedBytes
            dao.updateDownload(
                entity.copy(
                    status = DownloadStatus.PAUSED.name,
                    downloadedBytes = currentBytes
                )
            )
            activeJobs[downloadId]?.cancel()
            activeJobs.remove(downloadId)
            refreshForegroundService()
        }
    }

    fun cancelAndDelete(download: DownloadEntity) {
        scope.launch {
            activeJobs[download.id]?.cancel()
            activeJobs.remove(download.id)
            File(download.filePath).delete()
            File("${download.filePath}.part").delete()
            dao.deleteDownload(download.id)
            refreshForegroundService()
        }
    }

    /**
     * Generates and scans a harmless local PE32+ .exe sample so users can immediately test
     * type-based folder sorting, antivirus scanning, and .exe Sandbox analysis.
     */
    fun createAndScanSampleExe() {
        scope.launch {
            val exeDir = File(File(context.filesDir, "Downloads"), "Çalıştırılabilir")
            val sampleFile = ExeSandboxAnalyzer.createHarmlessSampleExe(exeDir)
            val scanResult = FileSecurityScanner.scanFile(sampleFile, "https://sandbox.novaweb.local/test/nova_sandbox_test.exe")
            val sandboxRep = ExeSandboxAnalyzer.inspect(sampleFile)

            dao.insertDownload(
                DownloadEntity(
                    fileName = sampleFile.name,
                    url = "https://sandbox.novaweb.local/test/nova_sandbox_test.exe",
                    category = "Çalıştırılabilir",
                    filePath = sampleFile.absolutePath,
                    mimeType = "application/vnd.microsoft.portable-executable",
                    totalBytes = sampleFile.length(),
                    downloadedBytes = sampleFile.length(),
                    status = DownloadStatus.COMPLETED.name,
                    scanStatus = scanResult.status.name,
                    scanRiskScore = sandboxRep.riskScore,
                    scanSummary = scanResult.summary,
                    sha256 = scanResult.sha256,
                    isExecutable = true,
                    sandboxSummary = "${sandboxRep.peFormat} • ${sandboxRep.architecture} • ${sandboxRep.verdict}"
                )
            )
        }
    }

    private fun notifyForeground(fileName: String, progress: Int) {
        val count = activeJobs.size.coerceAtLeast(1)
        DownloadForegroundService.updateOrStart(context, count, fileName, progress)
    }

    private fun refreshForegroundService() {
        if (activeJobs.isEmpty()) {
            DownloadForegroundService.stop(context)
        }
    }

    private fun uniqueFile(dir: File, name: String): File {
        var candidate = File(dir, name)
        if (!candidate.exists()) return candidate
        val base = name.substringBeforeLast('.', name)
        val ext = name.substringAfterLast('.', "")
        var index = 1
        while (candidate.exists()) {
            val nextName = if (ext.isNotEmpty()) "${base}_$index.$ext" else "${base}_$index"
            candidate = File(dir, nextName)
            index++
        }
        return candidate
    }

    private fun guessMimeFromName(fileName: String): String {
        val ext = fileName.substringAfterLast('.', "").lowercase()
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
    }
}
