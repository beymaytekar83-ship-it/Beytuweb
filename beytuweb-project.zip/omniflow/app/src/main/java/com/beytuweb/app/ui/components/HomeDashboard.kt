package com.beytuweb.app.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bookmarks
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.DashboardCustomize
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.beytuweb.app.R
import com.beytuweb.app.data.local.BookmarkEntity
import com.beytuweb.app.data.local.ShortcutEntity
import com.beytuweb.app.system.SystemTelemetry
import com.beytuweb.app.ui.AppDestination
import com.beytuweb.app.ui.theme.NovaCyan
import com.beytuweb.app.ui.theme.NovaEmerald
import com.beytuweb.app.ui.theme.NovaViolet
import com.beytuweb.app.vpn.VpnState

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HomeDashboard(
    isIncognito: Boolean,
    shortcuts: List<ShortcutEntity>,
    bookmarks: List<BookmarkEntity>,
    vpnState: VpnState,
    adBlockEnabled: Boolean,
    blockedCount: Long,
    telemetry: SystemTelemetry,
    onSearchOrUrl: (String, Boolean) -> Unit,
    onOpenUrl: (String) -> Unit,
    onAddShortcut: (String, String, Long) -> Unit,
    onDeleteShortcut: (Long) -> Unit,
    onToggleVpn: () -> Unit,
    onOpenVoice: () -> Unit,
    onNavigate: (AppDestination) -> Unit,
    modifier: Modifier = Modifier
) {
    var queryText by remember { mutableStateOf("") }
    var showAddShortcutDialog by remember { mutableStateOf(false) }
    var editShortcutsMode by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 720.dp),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Hero Banner Card
            item {
                Card(
                    shape = MaterialTheme.shapes.large,
                    border = BorderStroke(
                        1.dp,
                        if (isIncognito) NovaViolet.copy(alpha = 0.5f)
                        else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
                    ),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(170.dp)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.img_novaweb_hero_1794685274598),
                            contentDescription = "NovaWeb başlangıç görseli",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(
                                            Color(0x660A0E17),
                                            Color(0xE60A0E17)
                                        )
                                    )
                                )
                        )
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(18.dp),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    color = if (isIncognito) NovaViolet.copy(alpha = 0.25f) else NovaCyan.copy(alpha = 0.16f),
                                    shape = RoundedCornerShape(50),
                                    border = BorderStroke(
                                        1.dp,
                                        if (isIncognito) NovaViolet else NovaCyan.copy(alpha = 0.5f)
                                    )
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = if (isIncognito) Icons.Filled.VisibilityOff else Icons.Filled.Shield,
                                            contentDescription = null,
                                            tint = if (isIncognito) NovaViolet else NovaCyan,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(Modifier.width(6.dp))
                                        Text(
                                            text = if (isIncognito) "GİZLİ MOD • GEÇMİŞ KAYDEDİLMEZ" else "NOVAWEB SHIELD • HIZLI & GÜVENLİ",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color.White
                                        )
                                    }
                                }

                                Surface(
                                    color = if (vpnState.isConnected) NovaEmerald.copy(alpha = 0.25f) else Color.White.copy(alpha = 0.08f),
                                    shape = RoundedCornerShape(50),
                                    modifier = Modifier
                                        .testTag("home_vpn_chip")
                                        .clip(RoundedCornerShape(50))
                                        .clickable { onToggleVpn() }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.VpnKey,
                                            contentDescription = "VPN Kalkanı",
                                            tint = if (vpnState.isConnected) NovaEmerald else Color.White.copy(alpha = 0.8f),
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(Modifier.width(5.dp))
                                        Text(
                                            text = if (vpnState.isConnected) "VPN AÇIK" else "VPN KAPALI",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color.White
                                        )
                                    }
                                }
                            }

                            Column {
                                Text(
                                    text = if (isIncognito) "Gizli Oturum" else "NovaWeb AI Tarayıcı",
                                    style = MaterialTheme.typography.headlineMedium,
                                    color = Color.White
                                )
                                Text(
                                    text = if (isIncognito) {
                                        "Ziyaret edilen siteler, çerezler ve geçmiş sekme kapanınca silinir."
                                    } else {
                                        "YouTube, TikTok, AI arama, reklam engelleme ve sandbox koruması hazır."
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.White.copy(alpha = 0.82f)
                                )
                            }
                        }
                    }
                }
            }

            // Quick Search + AI Input Card
            item {
                Surface(
                    shape = RoundedCornerShape(24.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f)),
                    tonalElevation = 4.dp
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Search,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(start = 6.dp)
                        )
                        OutlinedTextField(
                            value = queryText,
                            onValueChange = { queryText = it },
                            placeholder = {
                                Text(
                                    "Web'de ara, URL yaz veya AI'ya sor...",
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                            keyboardActions = KeyboardActions(
                                onSearch = {
                                    if (queryText.isNotBlank()) onSearchOrUrl(queryText, false)
                                }
                            ),
                            colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color.Transparent,
                                unfocusedBorderColor = Color.Transparent
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("home_search_input")
                        )
                        IconButton(
                            onClick = onOpenVoice,
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("home_voice_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Mic,
                                contentDescription = "Sesli komut",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                        IconButton(
                            onClick = {
                                if (queryText.isNotBlank()) onSearchOrUrl(queryText, true)
                            },
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("home_ai_ask_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.AutoAwesome,
                                contentDescription = "Yapay Zekaya Sor",
                                tint = NovaEmerald
                            )
                        }
                    }
                }
            }

            // Live Security & Resource Strip
            item {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        TelemetryPillCard(
                            icon = Icons.Filled.Shield,
                            label = if (adBlockEnabled) "Engellenen Reklam" else "Reklam Kalkanı Kapalı",
                            value = "$blockedCount engellendi",
                            accent = if (adBlockEnabled) NovaEmerald else MaterialTheme.colorScheme.onSurfaceVariant,
                            onClick = { onNavigate(AppDestination.CONTROL_PANEL) }
                        )
                    }
                    item {
                        TelemetryPillCard(
                            icon = Icons.Filled.Memory,
                            label = "Sistem RAM",
                            value = "${(telemetry.usedRamPercent * 100).toInt()}% • ${telemetry.availableRamMb} MB boş",
                            accent = NovaCyan,
                            onClick = { onNavigate(AppDestination.CONTROL_PANEL) }
                        )
                    }
                    item {
                        TelemetryPillCard(
                            icon = Icons.Filled.Download,
                            label = "İndirilenler & Sandbox",
                            value = "Klasörlü & Korumalı",
                            accent = NovaViolet,
                            onClick = { onNavigate(AppDestination.DOWNLOADS) }
                        )
                    }
                }
            }

            // Customizable Shortcuts Section
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Hızlı Kısayollar",
                        style = MaterialTheme.typography.titleLarge
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        TextButton(
                            onClick = { editShortcutsMode = !editShortcutsMode },
                            modifier = Modifier.testTag("toggle_edit_shortcuts")
                        ) {
                            Text(if (editShortcutsMode) "Bitti" else "Düzenle")
                        }
                        TextButton(
                            onClick = { showAddShortcutDialog = true },
                            modifier = Modifier.testTag("add_shortcut_button")
                        ) {
                            Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Ekle")
                        }
                    }
                }

                Spacer(Modifier.height(8.dp))

                FlowRow(
                    maxItemsInEachRow = 4,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    shortcuts.forEach { shortcut ->
                        val accentColor = Color(shortcut.accentHex)
                        Surface(
                            shape = RoundedCornerShape(18.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f)),
                            modifier = Modifier
                                .width(78.dp)
                                .clip(RoundedCornerShape(18.dp))
                                .clickable { onOpenUrl(shortcut.url) }
                                .testTag("shortcut_${shortcut.title.lowercase()}")
                        ) {
                            Box(modifier = Modifier.padding(vertical = 12.dp, horizontal = 6.dp)) {
                                if (editShortcutsMode) {
                                    IconButton(
                                        onClick = { onDeleteShortcut(shortcut.id) },
                                        modifier = Modifier
                                            .align(Alignment.TopEnd)
                                            .size(22.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.Close,
                                            contentDescription = "Kısayolu sil",
                                            tint = MaterialTheme.colorScheme.error,
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                }
                                Column(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(42.dp)
                                            .clip(CircleShape)
                                            .background(accentColor.copy(alpha = 0.18f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = shortcut.badgeLetter,
                                            style = MaterialTheme.typography.titleLarge,
                                            color = accentColor,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    Spacer(Modifier.height(8.dp))
                                    Text(
                                        text = shortcut.title,
                                        style = MaterialTheme.typography.labelLarge,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Quick Hub Buttons
            item {
                Text(
                    text = "Tarayıcı Modülleri",
                    style = MaterialTheme.typography.titleLarge
                )
                Spacer(Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    QuickHubCard(
                        icon = Icons.Filled.Bookmarks,
                        title = "Yer İmleri",
                        subtitle = "${bookmarks.size} kayıt",
                        accent = NovaCyan,
                        onClick = { onNavigate(AppDestination.BOOKMARKS) },
                        modifier = Modifier.weight(1f).testTag("hub_bookmarks")
                    )
                    QuickHubCard(
                        icon = Icons.Filled.CloudDownload,
                        title = "İndirmeler",
                        subtitle = "Antivirüs & EXE",
                        accent = NovaEmerald,
                        onClick = { onNavigate(AppDestination.DOWNLOADS) },
                        modifier = Modifier.weight(1f).testTag("hub_downloads")
                    )
                    QuickHubCard(
                        icon = Icons.Filled.DashboardCustomize,
                        title = "Kontrol",
                        subtitle = "VPN & Chrome",
                        accent = NovaViolet,
                        onClick = { onNavigate(AppDestination.CONTROL_PANEL) },
                        modifier = Modifier.weight(1f).testTag("hub_control")
                    )
                }
            }
        }
    }

    if (showAddShortcutDialog) {
        AddShortcutDialog(
            onDismiss = { showAddShortcutDialog = false },
            onSave = { title, url, color ->
                onAddShortcut(title, url, color)
                showAddShortcutDialog = false
            }
        )
    }
}

@Composable
private fun TelemetryPillCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String,
    accent: Color,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, accent.copy(alpha = 0.35f)),
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Column {
                Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(value, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurface)
            }
        }
    }
}

@Composable
private fun QuickHubCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    accent: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(24.dp))
            Spacer(Modifier.height(10.dp))
            Text(title, style = MaterialTheme.typography.titleMedium, maxLines = 1)
            Text(
                subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun AddShortcutDialog(
    onDismiss: () -> Unit,
    onSave: (String, String, Long) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    val colorOptions = listOf(
        0xFF00E5FFL to "Camgöbeği",
        0xFF10B981L to "Zümrüt",
        0xFFA855F7L to "Mor",
        0xFFF59E0BL to "Kehribar",
        0xFFEF4444L to "Kırmızı"
    )
    var selectedColor by remember { mutableStateOf(colorOptions.first().first) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Yeni Kısayol Ekle") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Başlık (ör. Instagram)") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it },
                    label = { Text("URL (ör. instagram.com)") },
                    singleLine = true
                )
                Text("Simge Rengi", style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    colorOptions.forEach { (hex, _) ->
                        Box(
                            modifier = Modifier
                                .size(30.dp)
                                .clip(CircleShape)
                                .background(Color(hex))
                                .clickable { selectedColor = hex }
                                .padding(2.dp)
                        ) {
                            if (selectedColor == hex) {
                                Icon(
                                    Icons.Filled.Lock,
                                    contentDescription = null,
                                    tint = Color.Black,
                                    modifier = Modifier.align(Alignment.Center).size(14.dp)
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank() && url.isNotBlank()) {
                        onSave(title, url, selectedColor)
                    }
                }
            ) { Text("Kaydet") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("İptal") }
        }
    )
}
