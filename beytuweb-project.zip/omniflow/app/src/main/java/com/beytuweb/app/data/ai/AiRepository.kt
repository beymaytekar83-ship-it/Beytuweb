package com.beytuweb.app.data.ai

import kotlinx.coroutines.delay

data class AiResponse(
    val title: String,
    val content: String,
    val isPlaceholder: Boolean = true,
    val notice: String = "Örnek Yapay Zeka Yanıtı — Gerçek Gemini AI ve bulut senkronizasyonu için Firebase AI Logic kurulumunun onaylanması gerekir."
)

interface AiRepository {
    val isFirebaseConnected: Boolean
    suspend fun answerSearchQuery(query: String, activePageContext: String? = null): AiResponse
    suspend fun translatePageContent(pageTitle: String, pageSnippet: String, targetLanguage: String): AiResponse
    suspend fun explainSandboxReport(fileName: String, riskScore: Int, findings: List<String>): AiResponse
}

/**
 * Placeholder implementation used when Firebase setup is declined by the user.
 * Never calls direct Gemini REST endpoints or embeds API keys.
 */
class PlaceholderAiRepository : AiRepository {
    override val isFirebaseConnected: Boolean = false

    override suspend fun answerSearchQuery(query: String, activePageContext: String?): AiResponse {
        delay(450)
        val cleanQuery = query.trim()
        val contextNote = if (!activePageContext.isNullOrBlank()) {
            "\n\nAktif sayfa bağlamı algılandı: $activePageContext"
        } else ""

        val sampleBody = buildString {
            append("[Örnek Yanıt] \"$cleanQuery\" sorgusu için özet:\n")
            append("• Konu tarayıcı aramasıyla paralel olarak analiz edildi.\n")
            append("• Hızlı özet: Aradığınız başlık hakkında resmi dokümantasyon, video kaynakları ve güncel web sonuçları alttaki tarayıcı sekmesinde listelenmiştir.\n")
            append("• İpucu: Sesli komutla \"çevir\" veya \"reklam engelleyici aç\" diyerek tarayıcıyı yönetebilirsiniz.")
            append(contextNote)
        }

        return AiResponse(
            title = "NovaWeb AI Özeti (Örnek Mod)",
            content = sampleBody,
            isPlaceholder = true
        )
    }

    override suspend fun translatePageContent(
        pageTitle: String,
        pageSnippet: String,
        targetLanguage: String
    ): AiResponse {
        delay(500)
        val trimmed = pageSnippet.trim().take(700)
        val translatedPreview = if (trimmed.isBlank()) {
            "[Örnek Çeviri ($targetLanguage)] Sayfa başlığı: \"$pageTitle\". Sayfa içeriği canlı WebView üzerinden algılandı; gerçek zamanlı Gemini nöral çevirisi için Firebase AI Logic bağlantısı etkinleştirilmelidir."
        } else {
            "[Örnek Çeviri -> $targetLanguage]\nBaşlık: $pageTitle\n\nÖrnek Çevrilen Metin:\n$trimmed\n\n(Not: Tam sayfa anlamsal Gemini çevirisi Firebase AI Logic etkinleştirildiğinde otomatik devreye girer.)"
        }
        return AiResponse(
            title = "Sayfa Çevirisi • $targetLanguage",
            content = translatedPreview,
            isPlaceholder = true
        )
    }

    override suspend fun explainSandboxReport(
        fileName: String,
        riskScore: Int,
        findings: List<String>
    ): AiResponse {
        delay(350)
        val level = when {
            riskScore >= 60 -> "Yüksek Risk"
            riskScore >= 30 -> "Orta Risk (Dikkatli Olun)"
            else -> "Düşük Risk"
        }
        val findingsText = if (findings.isEmpty()) "Kritik API veya paketleyici anomalisi saptanmadı."
        else findings.joinToString("\n• ", prefix = "• ")

        return AiResponse(
            title = "AI Sandbox Değerlendirmesi: $level",
            content = "[Örnek Güvenlik Özeti] \"$fileName\" dosyası için statik PE & entropi analizi skoru: $riskScore/100.\n\nBulgular:\n$findingsText\n\nÖneri: Çalıştırılabilir dosyaları yalnızca güvendiğiniz kaynaklardan açın ve SHA-256 doğrulamasını kontrol edin.",
            isPlaceholder = true
        )
    }
}
