package com.beytuweb.app.chromeimport

import com.beytuweb.app.data.local.BookmarkEntity
import com.beytuweb.app.data.local.HistoryEntity
import com.beytuweb.app.data.local.ShortcutEntity
import org.json.JSONArray
import org.json.JSONObject

data class ChromeImportResult(
    val bookmarks: List<BookmarkEntity>,
    val history: List<HistoryEntity>,
    val shortcuts: List<ShortcutEntity> = emptyList(),
    val summary: String
)

object ChromeDataImporter {

    private val anchorRegex = Regex(
        """<DT><A\s+HREF="([^"]+)"[^>]*>(.*?)</A>""",
        setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)
    )
    private val folderRegex = Regex(
        """<DT><H3[^>]*>(.*?)</H3>""",
        setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)
    )

    fun parseImportedText(raw: String): ChromeImportResult {
        val trimmed = raw.trim()
        if (trimmed.isEmpty()) {
            return ChromeImportResult(emptyList(), emptyList(), emptyList(), "Boş dosya içeriği")
        }
        return if (trimmed.startsWith("{")) {
            parseJsonBackupOrChrome(trimmed)
        } else {
            parseNetscapeBookmarksHtml(trimmed)
        }
    }

    private fun parseNetscapeBookmarksHtml(html: String): ChromeImportResult {
        val bookmarks = mutableListOf<BookmarkEntity>()
        var currentFolder = "Chrome İçe Aktarım"

        html.lineSequence().forEach { line ->
            val folderMatch = folderRegex.find(line)
            if (folderMatch != null) {
                val folderName = stripHtml(folderMatch.groupValues[1]).trim()
                if (folderName.isNotBlank()) currentFolder = folderName
            }
            val linkMatch = anchorRegex.find(line)
            if (linkMatch != null) {
                val url = linkMatch.groupValues[1].trim()
                val title = stripHtml(linkMatch.groupValues[2]).trim().ifBlank { url }
                if (url.startsWith("http://") || url.startsWith("https://")) {
                    bookmarks += BookmarkEntity(
                        title = title,
                        url = url,
                        folder = currentFolder
                    )
                }
            }
        }

        return ChromeImportResult(
            bookmarks = bookmarks,
            history = emptyList(),
            summary = "Chrome HTML'den ${bookmarks.size} yer işareti içe aktarıldı."
        )
    }

    private fun parseJsonBackupOrChrome(jsonStr: String): ChromeImportResult {
        val root = JSONObject(jsonStr)
        val bookmarks = mutableListOf<BookmarkEntity>()
        val history = mutableListOf<HistoryEntity>()
        val shortcuts = mutableListOf<ShortcutEntity>()

        // 1. NovaWeb native backup format
        if (root.has("novawebBackupVersion")) {
            val bArr = root.optJSONArray("bookmarks") ?: JSONArray()
            for (i in 0 until bArr.length()) {
                val o = bArr.getJSONObject(i)
                bookmarks += BookmarkEntity(
                    title = o.optString("title"),
                    url = o.optString("url"),
                    folder = o.optString("folder", "Genel"),
                    createdAt = o.optLong("createdAt", System.currentTimeMillis())
                )
            }
            val hArr = root.optJSONArray("history") ?: JSONArray()
            for (i in 0 until hArr.length()) {
                val o = hArr.getJSONObject(i)
                history += HistoryEntity(
                    title = o.optString("title"),
                    url = o.optString("url"),
                    visitedAt = o.optLong("visitedAt", System.currentTimeMillis())
                )
            }
            val sArr = root.optJSONArray("shortcuts") ?: JSONArray()
            for (i in 0 until sArr.length()) {
                val o = sArr.getJSONObject(i)
                shortcuts += ShortcutEntity(
                    title = o.optString("title"),
                    url = o.optString("url"),
                    badgeLetter = o.optString("badgeLetter", "W"),
                    accentHex = o.optLong("accentHex", 0xFF00E5FF),
                    sortOrder = o.optInt("sortOrder", i)
                )
            }
            return ChromeImportResult(
                bookmarks = bookmarks,
                history = history,
                shortcuts = shortcuts,
                summary = "Yedekten ${bookmarks.size} yer işareti, ${history.size} geçmiş, ${shortcuts.size} kısayol geri yüklendi."
            )
        }

        // 2. Google Takeout Chrome BrowserHistory.json ("Browser History")
        if (root.has("Browser History")) {
            val arr = root.getJSONArray("Browser History")
            for (i in 0 until arr.length().coerceAtMost(500)) {
                val item = arr.getJSONObject(i)
                val url = item.optString("url")
                val title = item.optString("title").ifBlank { url }
                val timeUsec = item.optLong("time_usec", System.currentTimeMillis() * 1000L)
                if (url.startsWith("http")) {
                    history += HistoryEntity(
                        title = title,
                        url = url,
                        visitedAt = timeUsec / 1000L
                    )
                }
            }
        }

        // 3. Chrome Bookmarks JSON ("roots": { "bookmark_bar": { "children": [...] } })
        if (root.has("roots")) {
            val roots = root.getJSONObject("roots")
            val keys = roots.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                val node = roots.optJSONObject(key)
                if (node != null) {
                    collectChromeJsonNode(node, "Chrome • $key", bookmarks)
                }
            }
        }

        return ChromeImportResult(
            bookmarks = bookmarks,
            history = history,
            summary = "Google/Chrome JSON'dan ${bookmarks.size} yer işareti ve ${history.size} geçmiş kaydı aktarıldı."
        )
    }

    private fun collectChromeJsonNode(
        node: JSONObject,
        folderName: String,
        out: MutableList<BookmarkEntity>
    ) {
        val type = node.optString("type")
        if (type == "url") {
            val url = node.optString("url")
            val name = node.optString("name").ifBlank { url }
            if (url.startsWith("http")) {
                out += BookmarkEntity(title = name, url = url, folder = folderName)
            }
            return
        }
        val nextFolder = node.optString("name").takeIf { it.isNotBlank() } ?: folderName
        val children = node.optJSONArray("children") ?: return
        for (i in 0 until children.length()) {
            val child = children.optJSONObject(i) ?: continue
            collectChromeJsonNode(child, nextFolder, out)
        }
    }

    fun exportNovaBackupJson(
        bookmarks: List<BookmarkEntity>,
        history: List<HistoryEntity>,
        shortcuts: List<ShortcutEntity>,
        accountEmail: String
    ): String {
        val root = JSONObject()
        root.put("novawebBackupVersion", 1)
        root.put("exportedAt", System.currentTimeMillis())
        root.put("accountEmail", accountEmail)

        val bArr = JSONArray()
        bookmarks.forEach { b ->
            bArr.put(JSONObject().apply {
                put("title", b.title)
                put("url", b.url)
                put("folder", b.folder)
                put("createdAt", b.createdAt)
            })
        }
        root.put("bookmarks", bArr)

        val hArr = JSONArray()
        history.forEach { h ->
            hArr.put(JSONObject().apply {
                put("title", h.title)
                put("url", h.url)
                put("visitedAt", h.visitedAt)
            })
        }
        root.put("history", hArr)

        val sArr = JSONArray()
        shortcuts.forEach { s ->
            sArr.put(JSONObject().apply {
                put("title", s.title)
                put("url", s.url)
                put("badgeLetter", s.badgeLetter)
                put("accentHex", s.accentHex)
                put("sortOrder", s.sortOrder)
            })
        }
        root.put("shortcuts", sArr)
        return root.toString(2)
    }

    const val SAMPLE_CHROME_EXPORT_HTML = """<!DOCTYPE NETSCAPE-Bookmark-file-1>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<TITLE>Bookmarks</TITLE>
<H1>Bookmarks</H1>
<DL><p>
    <DT><H3>Chrome Çubuğu</H3>
    <DL><p>
        <DT><A HREF="https://mail.google.com">Gmail</A>
        <DT><A HREF="https://drive.google.com">Google Drive</A>
        <DT><A HREF="https://www.youtube.com">YouTube</A>
        <DT><A HREF="https://www.tiktok.com">TikTok</A>
    </DL><p>
    <DT><H3>Geliştirici & Araçlar</H3>
    <DL><p>
        <DT><A HREF="https://github.com">GitHub</A>
        <DT><A HREF="https://developer.android.com">Android Developers</A>
    </DL><p>
</DL><p>"""

    private fun stripHtml(s: String): String =
        s.replace(Regex("<[^>]*>"), "").replace("&amp;", "&").replace("&quot;", "\"")
}
