package com.beytuweb.app

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.webkit.WebView
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.DashboardCustomize
import androidx.compose.material.icons.filled.DesktopWindows
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.beytuweb.app.ui.AppDestination
import com.beytuweb.app.ui.BrowserTab
import com.beytuweb.app.ui.BrowserViewModel
import com.beytuweb.app.ui.components.AiSearchAnswerCard
import com.beytuweb.app.ui.components.BookmarksScreen
import com.beytuweb.app.ui.components.ControlPanelScreen
import com.beytuweb.app.ui.components.DownloadsScreen
import com.beytuweb.app.ui.components.HomeDashboard
import com.beytuweb.app.ui.components.NovaWebViewHost
import com.beytuweb.app.ui.components.PageTranslatorDialog
import com.beytuweb.app.ui.components.TabsSwitcherSheet
import com.beytuweb.app.ui.components.VoiceCommandSheet
import com.beytuweb.app.ui.theme.JetBrainsMonoFamily
import com.beytuweb.app.ui.theme.NovaEmerald
import com.beytuweb.app.ui.theme.NovaViolet
import com.beytuweb.app.ui.theme.NovaWebTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: BrowserViewModel = viewModel()
            NovaWebApp(viewModel = viewModel)
        }
    }
}

@Composable
fun NovaWebApp(viewModel: BrowserViewModel) {
    val context = LocalContext.current
    val prefs by viewModel.preferences.collectAsStateWithLifecycle()
    val tabs by viewModel.tabs.collectAsStateWithLifecycle()
    val activeTabId by viewModel.activeTabId.collectAsStateWithLifecycle()
    val destination by viewModel.destination.collectAsStateWithLifecycle()
    val bookmarks by viewModel.bookmarks.collectAsStateWithLifecycle()
    val shortcuts by viewModel.shortcuts.collectAsStateWithLifecycle()
    val history by viewModel.history.collectAsStateWithLifecycle()
    val downloads by viewModel.downloads.collectAsStateWithLifecycle()
    val vpnState by viewModel.vpnState.collectAsStateWithLifecycle()
    val aiState by viewModel.aiState.collectAsStateWithLifecycle()
    val translationState by viewModel.translationState.collectAsStateWithLifecycle()
    val telemetry by viewModel.telemetry.collectAsStateWithLifecycle()
    val sandboxReport by viewModel.sandboxReport.collectAsStateWithLifecycle()
    val sandboxAiNote by viewModel.sandboxAiNote.collectAsStateWithLifecycle()
    val statusToast by viewModel.statusToast.collectAsStateWithLifecycle()
    val pendingLoadUrl by viewModel.pendingLoadUrl.collectAsStateWithLifecycle()
    val requestVpnEvent by viewModel.requestVpnPermissionEvent.collectAsStateWithLifecycle()

    val activeTab = tabs.firstOrNull { it.id == activeTabId } ?: tabs.first()
    val webViewsMap = remember { mutableStateMapOf<String, WebView>() }
    val snackbarHostState = remember { SnackbarHostState() }

    var showTabsSheet by remember { mutableStateOf(false) }
    var showVoiceSheet by remember { mutableStateOf(false) }
    var showTranslateDialog by remember { mutableStateOf(false) }

    // Cleanup WebViews when composable leaves
    DisposableEffect(Unit) {
        onDispose {
            webViewsMap.values.forEach { wv ->
                try {
                    wv.stopLoading()
                    wv.destroy()
                } catch (_: Exception) {
                }
            }
            webViewsMap.clear()
        }
    }

    val vpnPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            viewModel.startVpnServiceAfterConsent()
        } else {
            viewModel.showToast("VPN bağlantısı için sistem izni gerekli.")
        }
    }

    val notifPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { }

    LaunchedEffect(requestVpnEvent) {
        if (requestVpnEvent) {
            viewModel.consumeVpnPermissionEvent()
            val prepIntent = VpnService.prepare(context)
            if (prepIntent != null) {
                vpnPermissionLauncher.launch(prepIntent)
            } else {
                viewModel.startVpnServiceAfterConsent()
            }
        }
    }

    LaunchedEffect(statusToast) {
        val msg = statusToast
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearStatusToast()
        }
    }

    val triggerDownloadWithNotifPermission: (String, String?, String?) -> Unit = { url, name, mime ->
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        viewModel.startDownload(url, name, mime)
    }

    val triggerPageTranslation: () -> Unit = {
        showTranslateDialog = true
    }

    val destroyWebViewForTab: (String) -> Unit = { tabId ->
        webViewsMap.remove(tabId)?.let { wv ->
            try {
                wv.stopLoading()
                wv.destroy()
            } catch (_: Exception) {
            }
        }
    }

    NovaWebTheme(
        darkTheme = prefs.darkThemeEnabled,
        isIncognito = activeTab.isIncognito && destination == AppDestination.BROWSER
    ) {
        Scaffold(
            contentWindowInsets = WindowInsets.safeDrawing,
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (destination) {
                    AppDestination.BROWSER -> {
                        val activeWebView = webViewsMap[activeTab.id]
                        BackHandler(enabled = !activeTab.isHome) {
                            if (activeWebView?.canGoBack() == true) {
                                activeWebView.goBack()
                            } else {
                                viewModel.goHomeInActiveTab()
                            }
                        }

                        val isCurrentBookmarked = remember(bookmarks, activeTab.url) {
                            activeTab.url.isNotBlank() && bookmarks.any { it.url.equals(activeTab.url, ignoreCase = true) }
                        }

                        Column(modifier = Modifier.fillMaxSize()) {
                            BrowserTopOmnibar(
                                activeTab = activeTab,
                                vpnConnected = vpnState.isConnected,
                                adBlockEnabled = prefs.adBlockEnabled,
                                isBookmarked = isCurrentBookmarked,
                                onSubmitInput = { viewModel.submitInput(it, forceAiQuery = false) },
                                onToggleVpn = { viewModel.toggleVpn() },
                                onVoiceClick = { showVoiceSheet = true },
                                onRefresh = {
                                    if (!activeTab.isHome) activeWebView?.reload()
                                },
                                onToggleBookmark = { viewModel.toggleCurrentPageBookmark() },
                                onOpenTranslate = { triggerPageTranslation() },
                                onToggleDesktop = { viewModel.toggleDesktopModeForActiveTab() },
                                onOpenBookmarks = { viewModel.navigateTo(AppDestination.BOOKMARKS) },
                                onAskAiPage = {
                                    val prompt = if (activeTab.isHome) "Bugün neler popüler?" else "${activeTab.title} sayfasını özetle"
                                    viewModel.askAi(prompt)
                                }
                            )

                            if (activeTab.isLoading) {
                                LinearProgressIndicator(
                                    progress = { (activeTab.progress / 100f).coerceIn(0.05f, 1f) },
                                    modifier = Modifier.fillMaxWidth().height(2.5.dp)
                                )
                            }

                            AiSearchAnswerCard(
                                aiState = aiState,
                                onDismiss = { viewModel.dismissAiCard() },
                                onAskFollowUp = { viewModel.askAi(it) }
                            )

                            Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                                if (activeTab.isHome) {
                                    HomeDashboard(
                                        isIncognito = activeTab.isIncognito,
                                        shortcuts = shortcuts,
                                        bookmarks = bookmarks,
                                        vpnState = vpnState,
                                        adBlockEnabled = prefs.adBlockEnabled,
                                        blockedCount = prefs.adsBlockedCount,
                                        telemetry = telemetry,
                                        onSearchOrUrl = { q, forceAi -> viewModel.submitInput(q, forceAi) },
                                        onOpenUrl = { viewModel.loadUrlInActiveTab(it) },
                                        onAddShortcut = { t, u, c -> viewModel.addShortcut(t, u, c) },
                                        onDeleteShortcut = { viewModel.deleteShortcut(it) },
                                        onToggleVpn = { viewModel.toggleVpn() },
                                        onOpenVoice = { showVoiceSheet = true },
                                        onNavigate = { viewModel.navigateTo(it) }
                                    )
                                } else {
                                    NovaWebViewHost(
                                        tab = activeTab,
                                        webViewsMap = webViewsMap,
                                        adBlockEnabled = prefs.adBlockEnabled,
                                        webForceDarkEnabled = prefs.webForceDarkEnabled,
                                        pendingLoadUrl = pendingLoadUrl,
                                        onConsumePendingLoad = { viewModel.consumePendingLoadUrl() },
                                        onProgressChanged = { id, p -> viewModel.onWebPageProgress(id, p) },
                                        onMetaUpdated = { id, url, title, back, fwd, record ->
                                            viewModel.onWebPageMetaUpdate(id, url, title, back, fwd, record)
                                        },
                                        onAdBlocked = { viewModel.onAdBlocked() },
                                        onDownloadRequested = triggerDownloadWithNotifPermission
                                    )
                                }
                            }

                            BrowserBottomBar(
                                canGoBack = !activeTab.isHome && activeTab.canGoBack,
                                canGoForward = !activeTab.isHome && activeTab.canGoForward,
                                tabCount = tabs.size,
                                isIncognito = activeTab.isIncognito,
                                activeDownloadsCount = downloads.count { it.status == "DOWNLOADING" },
                                onBack = {
                                    if (activeWebView?.canGoBack() == true) {
                                        activeWebView.goBack()
                                    } else {
                                        viewModel.goHomeInActiveTab()
                                    }
                                },
                                onForward = { activeWebView?.goForward() },
                                onHome = { viewModel.goHomeInActiveTab() },
                                onOpenTabs = { showTabsSheet = true },
                                onOpenDownloads = { viewModel.navigateTo(AppDestination.DOWNLOADS) },
                                onOpenControlPanel = { viewModel.navigateTo(AppDestination.CONTROL_PANEL) }
                            )
                        }
                    }

                    AppDestination.BOOKMARKS -> {
                        BookmarksScreen(
                            bookmarks = bookmarks,
                            onBack = { viewModel.navigateTo(AppDestination.BROWSER) },
                            onOpenUrl = { url -> viewModel.loadUrlInActiveTab(url) },
                            onAddBookmark = { t, u, f -> viewModel.addBookmark(t, u, f) },
                            onUpdateBookmark = { viewModel.updateBookmark(it) },
                            onDeleteBookmark = { viewModel.deleteBookmark(it) },
                            onPinToShortcut = { t, u -> viewModel.addShortcut(t, u, 0xFF00E5FF) },
                            onImportChromeRaw = { viewModel.importChromeData(it) }
                        )
                    }

                    AppDestination.DOWNLOADS -> {
                        DownloadsScreen(
                            downloads = downloads,
                            sandboxReport = sandboxReport,
                            sandboxAiNote = sandboxAiNote,
                            onBack = { viewModel.navigateTo(AppDestination.BROWSER) },
                            onStartDownload = { url -> triggerDownloadWithNotifPermission(url, null, null) },
                            onPauseDownload = { viewModel.pauseDownload(it) },
                            onResumeDownload = { viewModel.resumeDownload(it) },
                            onDeleteDownload = { viewModel.deleteDownload(it) },
                            onCreateSampleExe = { viewModel.createSampleExeForSandbox() },
                            onInspectExeInSandbox = { viewModel.openExeInSandbox(it) },
                            onCloseSandboxDialog = { viewModel.closeSandboxDialog() }
                        )
                    }

                    AppDestination.CONTROL_PANEL -> {
                        ControlPanelScreen(
                            prefs = prefs,
                            vpnState = vpnState,
                            telemetry = telemetry,
                            history = history,
                            activeWebViews = webViewsMap.values,
                            onBack = { viewModel.navigateTo(AppDestination.BROWSER) },
                            onToggleVpn = { viewModel.toggleVpn() },
                            onSetDarkTheme = { viewModel.setDarkTheme(it) },
                            onSetWebForceDark = { viewModel.setWebForceDark(it) },
                            onSetAdBlock = { viewModel.setAdBlock(it) },
                            onSetDesktopDefault = { viewModel.setDesktopModeDefault(it) },
                            onSetAiAutoAnswer = { viewModel.setAiAutoAnswer(it) },
                            onSetSearchEngine = { viewModel.setSearchEngine(it) },
                            onSetSyncEmail = { viewModel.setSyncAccountEmail(it) },
                            onOptimizeMemory = { viewModel.optimizeSystemMemory(it) },
                            onImportChromeRaw = { viewModel.importChromeData(it) },
                            onImportSampleChrome = { viewModel.importSampleChromePackage() },
                            onGenerateBackupJson = { viewModel.generateBackupJson() },
                            onOpenHistoryUrl = { url -> viewModel.loadUrlInActiveTab(url) },
                            onDeleteHistoryItem = { viewModel.deleteHistoryItem(it) },
                            onClearHistory = { viewModel.clearHistory() },
                            onToast = { viewModel.showToast(it) }
                        )
                    }
                }
            }
        }

        if (showTabsSheet) {
            TabsSwitcherSheet(
                tabs = tabs,
                activeTabId = activeTabId,
                onSelectTab = { viewModel.selectTab(it) },
                onCloseTab = { id -> viewModel.closeTab(id, destroyWebViewForTab) },
                onNewTab = { incognito -> viewModel.openNewTab(incognito = incognito) },
                onCloseAllIncognito = { viewModel.closeAllIncognitoTabs(destroyWebViewForTab) },
                onDismiss = { showTabsSheet = false }
            )
        }

        if (showVoiceSheet) {
            VoiceCommandSheet(
                onCommandRecognized = { spoken ->
                    viewModel.processVoiceCommand(spoken, onTriggerTranslate = triggerPageTranslation)
                },
                onDismiss = { showVoiceSheet = false }
            )
        }

        if (showTranslateDialog) {
            PageTranslatorDialog(
                currentLang = prefs.translationTargetLang,
                translationState = translationState,
                onTranslateRequest = { targetLang ->
                    val wv = webViewsMap[activeTab.id]
                    if (wv != null && !activeTab.isHome) {
                        wv.evaluateJavascript(
                            "(function(){return document.body ? document.body.innerText.slice(0,1200) : '';})();"
                        ) { raw ->
                            val clean = raw?.trim('"')
                                ?.replace("\\n", "\n")
                                ?.replace("\\\"", "\"")
                                .orEmpty()
                            viewModel.translateCurrentPage(clean, targetLang)
                        }
                    } else {
                        viewModel.translateCurrentPage("", targetLang)
                    }
                },
                onDismiss = {
                    showTranslateDialog = false
                    viewModel.resetTranslationState()
                }
            )
        }
    }
}

@Composable
private fun BrowserTopOmnibar(
    activeTab: BrowserTab,
    vpnConnected: Boolean,
    adBlockEnabled: Boolean,
    isBookmarked: Boolean,
    onSubmitInput: (String) -> Unit,
    onToggleVpn: () -> Unit,
    onVoiceClick: () -> Unit,
    onRefresh: () -> Unit,
    onToggleBookmark: () -> Unit,
    onOpenTranslate: () -> Unit,
    onToggleDesktop: () -> Unit,
    onOpenBookmarks: () -> Unit,
    onAskAiPage: () -> Unit
) {
    val focusManager = LocalFocusManager.current
    var addressText by remember(activeTab.id, activeTab.url, activeTab.isHome) {
        mutableStateOf(if (activeTab.isHome) "" else activeTab.url)
    }
    var showMoreMenu by remember { mutableStateOf(false) }

    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 4.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            // 1-Tap VPN Shield Icon
            IconButton(
                onClick = onToggleVpn,
                modifier = Modifier.minimumInteractiveComponentSize().testTag("top_vpn_toggle")
            ) {
                Icon(
                    imageVector = if (vpnConnected) Icons.Filled.VpnKey else Icons.Filled.Shield,
                    contentDescription = "VPN Kalkanı",
                    tint = when {
                        vpnConnected -> NovaEmerald
                        adBlockEnabled -> MaterialTheme.colorScheme.primary
                        else -> MaterialTheme.colorScheme.onSurfaceVariant
                    }
                )
            }

            // Address / Search Pill
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                border = BorderStroke(
                    1.dp,
                    if (activeTab.isIncognito) NovaViolet.copy(alpha = 0.65f)
                    else MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)
                ),
                modifier = Modifier.weight(1f).height(44.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (activeTab.isIncognito) Icons.Filled.VisibilityOff else Icons.Filled.Lock,
                        contentDescription = null,
                        tint = if (activeTab.isIncognito) NovaViolet else NovaEmerald,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
                        if (addressText.isEmpty()) {
                            Text(
                                text = if (activeTab.isIncognito) "Gizli arama veya URL..." else "Ara veya URL gir...",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        BasicTextField(
                            value = addressText,
                            onValueChange = { addressText = it },
                            singleLine = true,
                            textStyle = TextStyle(
                                color = MaterialTheme.colorScheme.onSurface,
                                fontFamily = JetBrainsMonoFamily,
                                fontSize = 13.sp
                            ),
                            cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                            keyboardActions = KeyboardActions(
                                onGo = {
                                    focusManager.clearFocus()
                                    onSubmitInput(addressText)
                                }
                            ),
                            modifier = Modifier.fillMaxWidth().testTag("omnibar_input")
                        )
                    }
                    IconButton(
                        onClick = onVoiceClick,
                        modifier = Modifier.size(34.dp).testTag("omnibar_voice_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Mic,
                            contentDescription = "Sesli komut",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            IconButton(
                onClick = onAskAiPage,
                modifier = Modifier.minimumInteractiveComponentSize().testTag("top_ai_button")
            ) {
                Icon(
                    imageVector = Icons.Filled.AutoAwesome,
                    contentDescription = "Yapay Zeka",
                    tint = NovaEmerald
                )
            }

            Box {
                IconButton(
                    onClick = { showMoreMenu = true },
                    modifier = Modifier.minimumInteractiveComponentSize().testTag("top_more_menu")
                ) {
                    Icon(Icons.Filled.MoreVert, contentDescription = "Seçenekler")
                }
                DropdownMenu(
                    expanded = showMoreMenu,
                    onDismissRequest = { showMoreMenu = false }
                ) {
                    DropdownMenuItem(
                        text = { Text("Yenile") },
                        leadingIcon = { Icon(Icons.Filled.Refresh, contentDescription = null) },
                        onClick = { showMoreMenu = false; onRefresh() }
                    )
                    DropdownMenuItem(
                        text = { Text(if (isBookmarked) "Yer İminden Çıkar" else "Yer İmlerine Ekle") },
                        leadingIcon = {
                            Icon(
                                if (isBookmarked) Icons.Filled.Bookmark else Icons.Filled.BookmarkBorder,
                                contentDescription = null
                            )
                        },
                        onClick = { showMoreMenu = false; onToggleBookmark() }
                    )
                    DropdownMenuItem(
                        text = { Text("Sayfayı Çevir") },
                        leadingIcon = { Icon(Icons.Filled.Translate, contentDescription = null) },
                        onClick = { showMoreMenu = false; onOpenTranslate() }
                    )
                    DropdownMenuItem(
                        text = { Text(if (activeTab.isDesktopMode) "Mobil Görünüm" else "Masaüstü Sitesi") },
                        leadingIcon = { Icon(Icons.Filled.DesktopWindows, contentDescription = null) },
                        onClick = { showMoreMenu = false; onToggleDesktop() }
                    )
                    DropdownMenuItem(
                        text = { Text("Yer İmleri Paneli") },
                        leadingIcon = { Icon(Icons.Filled.Bookmark, contentDescription = null) },
                        onClick = { showMoreMenu = false; onOpenBookmarks() }
                    )
                }
            }
        }
    }
}

@Composable
private fun BrowserBottomBar(
    canGoBack: Boolean,
    canGoForward: Boolean,
    tabCount: Int,
    isIncognito: Boolean,
    activeDownloadsCount: Int,
    onBack: () -> Unit,
    onForward: () -> Unit,
    onHome: () -> Unit,
    onOpenTabs: () -> Unit,
    onOpenDownloads: () -> Unit,
    onOpenControlPanel: () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 6.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 6.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                enabled = canGoBack,
                modifier = Modifier.minimumInteractiveComponentSize().testTag("nav_back")
            ) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Geri")
            }

            IconButton(
                onClick = onForward,
                enabled = canGoForward,
                modifier = Modifier.minimumInteractiveComponentSize().testTag("nav_forward")
            ) {
                Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = "İleri")
            }

            IconButton(
                onClick = onHome,
                modifier = Modifier.minimumInteractiveComponentSize().testTag("nav_home")
            ) {
                Icon(Icons.Filled.Home, contentDescription = "Ana Sayfa")
            }

            // Tab Count Badge Button
            Box(
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .clip(RoundedCornerShape(10.dp))
                    .clickable(onClick = onOpenTabs)
                    .padding(8.dp)
                    .testTag("nav_tabs_button"),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .border(
                            width = 2.dp,
                            color = if (isIncognito) NovaViolet else MaterialTheme.colorScheme.primary,
                            shape = RoundedCornerShape(6.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = tabCount.toString(),
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = if (isIncognito) NovaViolet else MaterialTheme.colorScheme.primary
                    )
                }
            }

            IconButton(
                onClick = onOpenDownloads,
                modifier = Modifier.minimumInteractiveComponentSize().testTag("nav_downloads")
            ) {
                Box {
                    Icon(
                        Icons.Filled.Download,
                        contentDescription = "İndirilenler",
                        tint = if (activeDownloadsCount > 0) NovaEmerald else MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            IconButton(
                onClick = onOpenControlPanel,
                modifier = Modifier.minimumInteractiveComponentSize().testTag("nav_control_panel")
            ) {
                Icon(Icons.Filled.DashboardCustomize, contentDescription = "Kontrol Paneli")
            }
        }
    }
}
