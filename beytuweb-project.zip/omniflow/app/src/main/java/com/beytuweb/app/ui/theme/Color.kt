package com.beytuweb.app.ui.theme

import androidx.compose.ui.graphics.Color

// Core Obsidian Midnight Palette
val NovaObsidian = Color(0xFF0A0E17)
val NovaSurface = Color(0xFF111827)
val NovaSurfaceVariant = Color(0xFF1B2436)
val NovaSurfaceElevated = Color(0xFF222D42)
val NovaOutline = Color(0xFF2E3B54)

// Signature Accents
val NovaCyan = Color(0xFF00E5FF)
val NovaCyanMuted = Color(0xFF0E7490)
val NovaEmerald = Color(0xFF10B981)
val NovaEmeraldMuted = Color(0xFF065F46)
val NovaViolet = Color(0xFFA855F7) // Incognito Stealth Accent
val NovaVioletSurface = Color(0xFF1D132B)
val NovaAmber = Color(0xFFF59E0B)
val NovaCrimson = Color(0xFFEF4444)

// Text Colors (Dark)
val NovaTextPrimary = Color(0xFFF1F5F9)
val NovaTextSecondary = Color(0xFF94A3B8)
val NovaTextMuted = Color(0xFF64748B)

// Clean Light Palette (when user toggles Dark Mode OFF)
val NovaLightBg = Color(0xFFF4F7FB)
val NovaLightSurface = Color(0xFFFFFFFF)
val NovaLightSurfaceVariant = Color(0xFFE6ECF5)
val NovaLightOutline = Color(0xFFCBD5E1)
val NovaLightPrimary = Color(0xFF0284C7)
val NovaLightTextPrimary = Color(0xFF0F172A)
val NovaLightTextSecondary = Color(0xFF475569)
