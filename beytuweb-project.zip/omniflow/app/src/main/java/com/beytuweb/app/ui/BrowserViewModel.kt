package com.beytuweb.app.ui

import android.app.Application
import android.webkit.CookieManager
import android.webkit.WebStorage
import android.webkit.WebView
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.beytuweb.app.chromeimport.ChromeDataImporter
import com.beytuweb.app.data.ai.AiRepository
import com.beytuweb.app.data.ai.AiResponse
import com.beytuweb.app.data.ai.PlaceholderAiRepository
import com.beytuweb.app.data.browser.BrowserRepository
import com.beytuweb.app.data.local.BookmarkEntity
import com.beytuweb.app.data.local.DownloadEntity
import com.beytuweb.app.data.local.HistoryEntity
import com.beytuweb.app.data.local.NovaDatabase
import com.beytuweb.app.data.local.ShortcutEntity
import com.beytuweb.app.data.prefs.BrowserPreferences
import com.beytuweb.app.data.prefs.UserPreferencesRepository
import com.beytuweb.app.downloads.DownloadManagerEngine
import com.beytuweb.app.security.ExeSandboxAnalyzer
import com.beytuweb.app.security.ExeSandboxReport
import com.beytuweb.app.system.SystemMonitor
import com.beytuweb.app.system.SystemTelemetry
import com.beytuweb.app.vpn.NovaVpnService
import com.beytuweb.app.vpn.VpnState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.net.URLEncoder
import java.util.UUID

enum class AppDestination {
    BROWSER,
    BOOKMARKS,
    DOWNLOADS,
    CONTROL_PANEL
}

data class BrowserTab(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "Yeni Sekme",
    val url: String = "",
    val isHome: Boolean = true,
    val isIncognito: Boolean = false,
    val isLoading: Boolean = false,
    val progress: Int = 0,
    val canGoBack: Boolean = false,
    val canGoForward: Boolean = false,
    val isDesktopMode: Boolean = false
)

sealed interface AiUiState {
    data object Idle : AiUiState
    data object Loading : AiUiState
    data class Success(val response: AiResponse, val query: String) : AiUiState
    data class Error(val message: String) : AiUiState
}

class BrowserViewModel(application: Application) : AndroidViewModel(application) {

    private val db = NovaDatabase.getInstance(application)
    private val prefsRepo = UserPreferencesRepository(application)
    private val repository = BrowserRepository(db.novaDao(), prefsRepo)
    private val downloadEngine = DownloadManagerEngine(application, db.novaDao())
    private val aiRepository: AiRepository = PlaceholderAiRepository()

    val preferences: StateFlow<BrowserPreferences> = repository.preferences.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000L), BrowserPreferences()
    )
    val bookmarks: StateFlow<List<BookmarkEntity>> = repository.bookmarks.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList()
    )
    val history: StateFlow<List<HistoryEntity>> = repository.history.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList()
    )
    val shortcuts: StateFlow<List<ShortcutEntity>> = repository.shortcuts.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList()
    )
    val downloads: StateFlow<List<DownloadEntity>> = repository.downloads.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList()
    )
    val vpnState: StateFlow<VpnState> = NovaVpnService.vpnState

    private val initialTab = BrowserTab(title = "Başlangıç", isHome = true)
    private val _tabs = MutableStateFlow(listOf(initialTab))
    val tabs: StateFlow<List<BrowserTab>> = _tabs.asStateFlow()

    private val _activeTabId = MutableStateFlow(initialTab.id)
    val activeTabId: StateFlow<String> = _activeTabId.asStateFlow()

    private val _destination = MutableStateFlow(AppDestination.BROWSER)
    val destination: StateFlow<AppDestination> = _destination.asStateFlow()

    private val _aiState = MutableStateFlow<AiUiState>(AiUiState.Idle)
    val aiState: StateFlow<AiUiState> = _aiState.asStateFlow()

    private val _translationState = MutableStateFlow<AiUiState>(AiUiState.Idle)
    val translationState: StateFlow<AiUiState> = _translationState.asStateFlow()

    private val _telemetry = MutableStateFlow(SystemTelemetry())
    val telemetry: StateFlow<SystemTelemetry> = _telemetry.asStateFlow()

    private val _sandboxReport = MutableStateFlow<ExeSandboxReport?>(null)
    val sandboxReport: StateFlow<ExeSandboxReport?> = _sandboxReport.asStateFlow()

    private val _sandboxAiNote = MutableStateFlow<AiResponse?>(null)
    val sandboxAiNote: StateFlow<AiResponse?> = _sandboxAiNote.asStateFlow()

    private val _statusToast = MutableStateFlow<String?>(null)
    val statusToast: StateFlow<String?> = _statusToast.asStateFlow()

    private val _sessionBlockedAds = MutableStateFlow(0)
    val sessionBlockedAds: StateFlow<Int> = _sessionBlockedAds.asStateFlow()

    // Request flag for VPN consent handled by Activity launcher
    private val _requestVpnPermissionEvent = MutableStateFlow(false)
    val requestVpnPermissionEvent: StateFlow<Boolean> = _requestVpnPermissionEvent.asStateFlow()

    // Navigation trigger for active WebView
    private val _pendingLoadUrl = MutableStateFlow<Pair<String, String>?>(null)
    val pendingLoadUrl: StateFlow<Pair<String, String>?> = _pendingLoadUrl.asStateFlow()

    init {
        viewModelScope.launch {
            repository.ensureDefaultsSeeded()
        }
        startTelemetryLoop()
    }

    private fun startTelemetryLoop() {
        viewModelScope.launch {
            while (true) {
                val stats = withContext(Dispatchers.Default) {
                    SystemMonitor.collectTelemetry(getApplication(), _tabs.value.size)
                }
                _telemetry.value = stats
                delay(2500L)
            }
        }
    }

    fun activeTab(): BrowserTab =
        _tabs.value.firstOrNull { it.id == _activeTabId.value } ?: _tabs.value.first()

    fun navigateTo(dest: AppDestination) {
        _destination.value = dest
    }

    fun clearStatusToast() {
        _statusToast.value = null
    }

    fun showToast(message: String) {
        _statusToast.value = message
    }

    fun submitInput(rawInput: String, forceAiQuery: Boolean = false) {
        val input = rawInput.trim()
        if (input.isEmpty()) return

        _destination.value = AppDestination.BROWSER

        val isLikelyUrl = !forceAiQuery && (
            input.startsWith("http://", ignoreCase = true) ||
                input.startsWith("https://", ignoreCase = true) ||
                (!input.contains(' ') && input.contains('.') && !input.endsWith('.'))
            )

        if (isLikelyUrl) {
            val normalized = if (input.startsWith("http://") || input.startsWith("https://")) {
                input
            } else {
                "https://$input"
            }
            loadUrlInActiveTab(normalized)
        } else {
            val searchUrl = buildSearchUrl(input, preferences.value.searchEngine)
            loadUrlInActiveTab(searchUrl)
            if (preferences.value.aiAutoAnswerEnabled || forceAiQuery) {
                askAi(input)
            }
        }
    }

    fun loadUrlInActiveTab(url: String) {
        val tabId = _activeTabId.value
        _destination.value = AppDestination.BROWSER
        _tabs.update { list ->
            list.map {
                if (it.id == tabId) it.copy(url = url, isHome = false, isLoading = true) else it
            }
        }
        _pendingLoadUrl.value = tabId to url
    }

    fun consumePendingLoadUrl() {
        _pendingLoadUrl.value = null
    }

    fun goHomeInActiveTab() {
        val tabId = _activeTabId.value
        _tabs.update { list ->
            list.map {
                if (it.id == tabId) it.copy(isHome = true, url = "", title = if (it.isIncognito) "Gizli Sekme" else "Başlangıç", isLoading = false, progress = 0)
                else it
            }
        }
    }

    fun openNewTab(incognito: Boolean = false, initialUrl: String? = null) {
        val newTab = BrowserTab(
            title = if (incognito) "Gizli Sekme" else "Başlangıç",
            url = initialUrl.orEmpty(),
            isHome = initialUrl.isNullOrBlank(),
            isIncognito = incognito,
            isDesktopMode = preferences.value.desktopModeDefault
        )
        _tabs.update { it + newTab }
        _activeTabId.value = newTab.id
        _destination.value = AppDestination.BROWSER
        if (!initialUrl.isNullOrBlank()) {
            _pendingLoadUrl.value = newTab.id to initialUrl
        }
    }

    fun selectTab(tabId: String) {
        if (_tabs.value.any { it.id == tabId }) {
            _activeTabId.value = tabId
            _destination.value = AppDestination.BROWSER
        }
    }

    fun closeTab(tabId: String, onCleanupWebView: (String) -> Unit = {}) {
        val closingTab = _tabs.value.firstOrNull { it.id == tabId }
        onCleanupWebView(tabId)
        val remaining = _tabs.value.filterNot { it.id == tabId }
        if (remaining.isEmpty()) {
            val fresh = BrowserTab(title = "Başlangıç", isHome = true)
            _tabs.value = listOf(fresh)
            _activeTabId.value = fresh.id
        } else {
            _tabs.value = remaining
            if (_activeTabId.value == tabId) {
                _activeTabId.value = remaining.last().id
            }
        }
        if (closingTab?.isIncognito == true && remaining.none { it.isIncognito }) {
            purgeIncognitoSessionData()
        }
    }

    fun closeAllIncognitoTabs(onCleanupWebView: (String) -> Unit = {}) {
        val incognitoIds = _tabs.value.filter { it.isIncognito }.map { it.id }
        incognitoIds.forEach { onCleanupWebView(it) }
        val normalTabs = _tabs.value.filterNot { it.isIncognito }
        if (normalTabs.isEmpty()) {
            val fresh = BrowserTab(title = "Başlangıç", isHome = true)
            _tabs.value = listOf(fresh)
            _activeTabId.value = fresh.id
        } else {
            _tabs.value = normalTabs
            if (normalTabs.none { it.id == _activeTabId.value }) {
                _activeTabId.value = normalTabs.last().id
            }
        }
        purgeIncognitoSessionData()
        _statusToast.value = "Tüm gizli sekmeler ve oturum verileri temizlendi."
    }

    private fun purgeIncognitoSessionData() {
        try {
            CookieManager.getInstance().removeSessionCookies(null)
            WebStorage.getInstance().deleteAllData()
        } catch (_: Exception) {
        }
    }

    fun toggleDesktopModeForActiveTab() {
        val id = _activeTabId.value
        _tabs.update { list ->
            list.map { if (it.id == id) it.copy(isDesktopMode = !it.isDesktopMode) else it }
        }
    }

    fun onWebPageProgress(tabId: String, progress: Int) {
        _tabs.update { list ->
            list.map {
                if (it.id == tabId) it.copy(progress = progress, isLoading = progress in 1..99) else it
            }
        }
    }

    fun onWebPageMetaUpdate(
        tabId: String,
        url: String?,
        title: String?,
        canGoBack: Boolean,
        canGoForward: Boolean,
        recordHistoryVisit: Boolean
    ) {
        val target = _tabs.value.firstOrNull { it.id == tabId } ?: return
        val nextUrl = url ?: target.url
        val nextTitle = title?.takeIf { it.isNotBlank() } ?: target.title

        _tabs.update { list ->
            list.map {
                if (it.id == tabId) {
                    it.copy(
                        url = nextUrl,
                        title = nextTitle,
                        isHome = false,
                        canGoBack = canGoBack,
                        canGoForward = canGoForward
                    )
                } else it
            }
        }

        // Strict Incognito isolation: NEVER record incognito pages in history!
        if (recordHistoryVisit && !target.isIncognito && nextUrl.startsWith("http")) {
            viewModelScope.launch {
                repository.recordHistory(nextTitle, nextUrl)
            }
        }
    }

    fun onAdBlocked() {
        _sessionBlockedAds.update { it + 1 }
        viewModelScope.launch {
            repository.incrementAdsBlocked()
        }
    }

    fun askAi(query: String) {
        val current = activeTab()
        val pageContext = if (!current.isHome) "${current.title} (${current.url})" else null
        viewModelScope.launch {
            _aiState.value = AiUiState.Loading
            try {
                val resp = aiRepository.answerSearchQuery(query, pageContext)
                _aiState.value = AiUiState.Success(resp, query)
            } catch (e: Exception) {
                _aiState.value = AiUiState.Error(e.localizedMessage ?: "AI yanıtı alınamadı.")
            }
        }
    }

    fun dismissAiCard() {
        _aiState.value = AiUiState.Idle
    }

    fun translateCurrentPage(extractedText: String, targetLang: String) {
        val current = activeTab()
        viewModelScope.launch {
            repository.setTranslationLanguage(targetLang)
            _translationState.value = AiUiState.Loading
            try {
                val resp = aiRepository.translatePageContent(
                    pageTitle = current.title,
                    pageSnippet = extractedText,
                    targetLanguage = targetLang
                )
                _translationState.value = AiUiState.Success(resp, targetLang)
            } catch (e: Exception) {
                _translationState.value = AiUiState.Error(e.localizedMessage ?: "Çeviri başarısız oldu.")
            }
        }
    }

    fun resetTranslationState() {
        _translationState.value = AiUiState.Idle
    }

    fun processVoiceCommand(rawSpeech: String, onTriggerTranslate: () -> Unit) {
        val text = rawSpeech.trim().lowercase()
        when {
            text.contains("youtube") -> {
                loadUrlInActiveTab("https://m.youtube.com")
                _statusToast.value = "Sesli komut: YouTube açılıyor"
            }
            text.contains("tiktok") -> {
                loadUrlInActiveTab("https://www.tiktok.com")
                _statusToast.value = "Sesli komut: TikTok açılıyor"
            }
            text.contains("gmail") -> {
                loadUrlInActiveTab("https://mail.google.com")
                _statusToast.value = "Sesli komut: Gmail açılıyor"
            }
            text.contains("gizli") -> {
                openNewTab(incognito = true)
                _statusToast.value = "Sesli komut: Gizli sekme açıldı"
            }
            text.contains("yeni sekme") || text.contains("sekme aç") -> {
                openNewTab(incognito = false)
                _statusToast.value = "Sesli komut: Yeni sekme açıldı"
            }
            text.contains("sekmeyi kapat") || text.contains("sekme kapat") -> {
                closeTab(_activeTabId.value)
                _statusToast.value = "Sesli komut: Aktif sekme kapatıldı"
            }
            text.contains("vpn") && (text.contains("kapat") || text.contains("durdur")) -> {
                if (vpnState.value.isConnected) toggleVpn()
                _statusToast.value = "Sesli komut: VPN kapatıldı"
            }
            text.contains("vpn") -> {
                if (!vpnState.value.isConnected) toggleVpn()
                _statusToast.value = "Sesli komut: VPN Kalkanı etkinleştiriliyor"
            }
            text.contains("reklam") -> {
                val next = !preferences.value.adBlockEnabled
                setAdBlock(next)
                _statusToast.value = if (next) "Reklam engelleyici açıldı" else "Reklam engelleyici kapatıldı"
            }
            text.contains("indirilen") -> {
                navigateTo(AppDestination.DOWNLOADS)
            }
            text.contains("yer imi") || text.contains("yer imleri") -> {
                navigateTo(AppDestination.BOOKMARKS)
            }
            text.contains("kontrol") || text.contains("ayarlar") || text.contains("sistem") -> {
                navigateTo(AppDestination.CONTROL_PANEL)
            }
            text.contains("çevir") -> {
                onTriggerTranslate()
            }
            else -> {
                submitInput(rawSpeech, forceAiQuery = true)
            }
        }
    }

    fun toggleVpn() {
        if (vpnState.value.isConnected) {
            NovaVpnService.stop(getApplication())
        } else {
            _requestVpnPermissionEvent.value = true
        }
    }

    fun consumeVpnPermissionEvent() {
        _requestVpnPermissionEvent.value = false
    }

    fun startVpnServiceAfterConsent() {
        NovaVpnService.start(getApplication())
    }

    // Bookmarks & Shortcuts
    fun toggleCurrentPageBookmark() {
        val tab = activeTab()
        if (tab.isHome || tab.url.isBlank()) return
        viewModelScope.launch {
            val added = repository.toggleBookmark(tab.title, tab.url)
            _statusToast.value = if (added) "Yer imlerine eklendi" else "Yer imlerinden kaldırıldı"
        }
    }

    fun addBookmark(title: String, url: String, folder: String) {
        viewModelScope.launch {
            repository.addBookmark(title, url, folder)
            _statusToast.value = "Yer imi kaydedildi"
        }
    }

    fun updateBookmark(bookmark: BookmarkEntity) {
        viewModelScope.launch { repository.updateBookmark(bookmark) }
    }

    fun deleteBookmark(id: Long) {
        viewModelScope.launch { repository.deleteBookmark(id) }
    }

    fun addShortcut(title: String, url: String, accentHex: Long) {
        val cleanUrl = if (url.startsWith("http")) url else "https://$url"
        viewModelScope.launch {
            repository.addShortcut(title, cleanUrl, accentHex)
            _statusToast.value = "Kısayol eklendi"
        }
    }

    fun deleteShortcut(id: Long) {
        viewModelScope.launch { repository.deleteShortcut(id) }
    }

    fun deleteHistoryItem(id: Long) {
        viewModelScope.launch { repository.deleteHistoryItem(id) }
    }

    fun clearHistory() {
        viewModelScope.launch {
            repository.clearHistory()
            _statusToast.value = "Tarama geçmişi temizlendi"
        }
    }

    // Downloads & Sandbox
    fun startDownload(url: String, fileName: String? = null, mimeType: String? = null) {
        downloadEngine.enqueueDownload(url, fileName, mimeType)
        _statusToast.value = "İndirme başlatıldı: ${fileName ?: url.substringAfterLast('/')}"
    }

    fun pauseDownload(id: Long) = downloadEngine.pauseDownload(id)

    fun resumeDownload(id: Long) = downloadEngine.startOrResume(id)

    fun deleteDownload(entity: DownloadEntity) = downloadEngine.cancelAndDelete(entity)

    fun createSampleExeForSandbox() {
        downloadEngine.createAndScanSampleExe()
        _statusToast.value = "Örnek PE32+ .exe oluşturuldu ve antivirüs taramasından geçirildi"
    }

    fun openExeInSandbox(download: DownloadEntity) {
        viewModelScope.launch {
            val report = withContext(Dispatchers.IO) {
                ExeSandboxAnalyzer.inspect(File(download.filePath))
            }
            _sandboxReport.value = report
            _sandboxAiNote.value = aiRepository.explainSandboxReport(
                fileName = report.fileName,
                riskScore = report.riskScore,
                findings = report.findings
            )
        }
    }

    fun closeSandboxDialog() {
        _sandboxReport.value = null
        _sandboxAiNote.value = null
    }

    // System Monitor & Optimization
    fun optimizeSystemMemory(activeWebViews: Collection<WebView>) {
        viewModelScope.launch {
            val freedMb = withContext(Dispatchers.Main) {
                SystemMonitor.optimizeMemory(getApplication(), activeWebViews)
            }
            _telemetry.value = withContext(Dispatchers.Default) {
                SystemMonitor.collectTelemetry(getApplication(), _tabs.value.size)
            }
            _statusToast.value = "Bellek optimize edildi (${String.format("%.1f", freedMb)} MB önbellek temizlendi)"
        }
    }

    // Chrome / Google Import & Backup
    fun importChromeData(rawContent: String) {
        viewModelScope.launch {
            try {
                val res = withContext(Dispatchers.IO) {
                    repository.importChromeOrBackup(rawContent)
                }
                _statusToast.value = res.summary
            } catch (e: Exception) {
                _statusToast.value = "İçe aktarma hatası: ${e.localizedMessage ?: "Geçersiz format"}"
            }
        }
    }

    fun importSampleChromePackage() {
        importChromeData(ChromeDataImporter.SAMPLE_CHROME_EXPORT_HTML)
    }

    suspend fun generateBackupJson(): String =
        repository.createBackupJson(preferences.value.syncAccountEmail)

    // Preferences
    fun setDarkTheme(enabled: Boolean) = viewModelScope.launch { repository.setDarkTheme(enabled) }
    fun setWebForceDark(enabled: Boolean) = viewModelScope.launch { repository.setWebForceDark(enabled) }
    fun setAdBlock(enabled: Boolean) = viewModelScope.launch { repository.setAdBlock(enabled) }
    fun setDesktopModeDefault(enabled: Boolean) = viewModelScope.launch { repository.setDesktopModeDefault(enabled) }
    fun setAiAutoAnswer(enabled: Boolean) = viewModelScope.launch { repository.setAiAutoAnswer(enabled) }
    fun setSearchEngine(engine: String) = viewModelScope.launch { repository.setSearchEngine(engine) }
    fun setSyncAccountEmail(email: String) = viewModelScope.launch { repository.setSyncAccountEmail(email) }

    private fun buildSearchUrl(query: String, engine: String): String {
        val encoded = URLEncoder.encode(query, "UTF-8")
        return when (engine) {
            "DuckDuckGo" -> "https://duckduckgo.com/?q=$encoded"
            "Bing" -> "https://www.bing.com/search?q=$encoded"
            else -> "https://www.google.com/search?q=$encoded"
        }
    }
}
