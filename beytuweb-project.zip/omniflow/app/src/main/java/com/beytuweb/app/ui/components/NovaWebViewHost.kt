package com.beytuweb.app.ui.components

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.PermissionRequest
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import com.beytuweb.app.security.AdBlockerEngine
import com.beytuweb.app.ui.BrowserTab

private const val MOBILE_USER_AGENT =
    "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"
private const val DESKTOP_USER_AGENT =
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun NovaWebViewHost(
    tab: BrowserTab,
    webViewsMap: MutableMap<String, WebView>,
    adBlockEnabled: Boolean,
    webForceDarkEnabled: Boolean,
    pendingLoadUrl: Pair<String, String>?,
    onConsumePendingLoad: () -> Unit,
    onProgressChanged: (String, Int) -> Unit,
    onMetaUpdated: (String, String?, String?, Boolean, Boolean, Boolean) -> Unit,
    onAdBlocked: () -> Unit,
    onDownloadRequested: (url: String, fileName: String?, mimeType: String?) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val latestAdBlock by rememberUpdatedState(adBlockEnabled)
    val latestForceDark by rememberUpdatedState(webForceDarkEnabled)
    val latestOnAdBlocked by rememberUpdatedState(onAdBlocked)
    val latestOnMetaUpdated by rememberUpdatedState(onMetaUpdated)
    val latestOnProgress by rememberUpdatedState(onProgressChanged)
    val latestOnDownload by rememberUpdatedState(onDownloadRequested)

    var customFullscreenView by remember { mutableStateOf<View?>(null) }
    var customViewCallback by remember { mutableStateOf<WebChromeClient.CustomViewCallback?>(null) }

    val webView = remember(tab.id) {
        webViewsMap.getOrPut(tab.id) {
            WebView(context).apply {
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                setBackgroundColor(android.graphics.Color.parseColor("#0A0E17"))

                settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    @Suppress("DEPRECATION")
                    databaseEnabled = true
                    mediaPlaybackRequiresUserGesture = false
                    useWideViewPort = true
                    loadWithOverviewMode = true
                    setSupportZoom(true)
                    builtInZoomControls = true
                    displayZoomControls = false
                    allowFileAccess = true
                    allowContentAccess = true
                    javaScriptCanOpenWindowsAutomatically = true
                    mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                    cacheMode = if (tab.isIncognito) WebSettings.LOAD_NO_CACHE else WebSettings.LOAD_DEFAULT
                    userAgentString = if (tab.isDesktopMode) DESKTOP_USER_AGENT else MOBILE_USER_AGENT
                }

                val wv = this
                CookieManager.getInstance().apply {
                    setAcceptCookie(true)
                    setAcceptThirdPartyCookies(wv, !tab.isIncognito)
                }

                setDownloadListener { url, _, contentDisposition, mimetype, _ ->
                    val name = URLUtil.guessFileName(url, contentDisposition, mimetype)
                    latestOnDownload(url, name, mimetype)
                }

                webChromeClient = object : WebChromeClient() {
                    override fun onProgressChanged(view: WebView?, newProgress: Int) {
                        latestOnProgress(tab.id, newProgress)
                    }

                    override fun onReceivedTitle(view: WebView?, title: String?) {
                        if (view != null) {
                            latestOnMetaUpdated(
                                tab.id,
                                view.url,
                                title,
                                view.canGoBack(),
                                view.canGoForward(),
                                false
                            )
                        }
                    }

                    override fun onPermissionRequest(request: PermissionRequest?) {
                        request?.grant(request.resources)
                    }

                    override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                        customFullscreenView = view
                        customViewCallback = callback
                    }

                    override fun onHideCustomView() {
                        customFullscreenView = null
                        customViewCallback?.onCustomViewHidden()
                        customViewCallback = null
                    }
                }

                webViewClient = object : WebViewClient() {
                    override fun shouldInterceptRequest(
                        view: WebView?,
                        request: WebResourceRequest?
                    ): WebResourceResponse? {
                        val reqUrl = request?.url?.toString()
                        if (latestAdBlock && AdBlockerEngine.isAdRequest(reqUrl)) {
                            latestOnAdBlocked()
                            return AdBlockerEngine.createEmptyAdResponse()
                        }
                        return super.shouldInterceptRequest(view, request)
                    }

                    override fun shouldOverrideUrlLoading(
                        view: WebView?,
                        request: WebResourceRequest?
                    ): Boolean {
                        val uri = request?.url ?: return false
                        val scheme = uri.scheme?.lowercase() ?: return false
                        if (scheme == "http" || scheme == "https") {
                            return false
                        }
                        if (scheme == "intent") {
                            try {
                                val intent = Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME)
                                val fallback = intent.getStringExtra("browser_fallback_url")
                                if (!fallback.isNullOrBlank()) {
                                    view?.loadUrl(fallback)
                                }
                            } catch (_: Exception) {
                            }
                            return true
                        }
                        // Ignore custom app deep links like snssdk:// or youtube:// inside browser
                        return true
                    }

                    override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                        if (view != null) {
                            latestOnMetaUpdated(
                                tab.id,
                                url,
                                view.title,
                                view.canGoBack(),
                                view.canGoForward(),
                                false
                            )
                        }
                    }

                    override fun onPageFinished(view: WebView?, url: String?) {
                        if (view != null) {
                            if (latestAdBlock) {
                                view.evaluateJavascript(AdBlockerEngine.COSMETIC_AD_HIDE_JS, null)
                            }
                            latestOnMetaUpdated(
                                tab.id,
                                url,
                                view.title,
                                view.canGoBack(),
                                view.canGoForward(),
                                true
                            )
                        }
                    }
                }

                if (tab.url.isNotBlank()) {
                    loadUrl(tab.url)
                }
            }
        }
    }

    // Apply live dark mode & desktop mode updates
    LaunchedEffect(tab.id, webForceDarkEnabled, tab.isDesktopMode) {
        val targetUa = if (tab.isDesktopMode) DESKTOP_USER_AGENT else MOBILE_USER_AGENT
        if (webView.settings.userAgentString != targetUa) {
            webView.settings.userAgentString = targetUa
            if (!tab.isHome && tab.url.isNotBlank()) {
                webView.reload()
            }
        }
        applyWebForceDark(webView, webForceDarkEnabled)
    }

    // Trigger pending loads for this tab
    LaunchedEffect(pendingLoadUrl, tab.id) {
        val pending = pendingLoadUrl
        if (pending != null && pending.first == tab.id) {
            if (webView.url != pending.second) {
                webView.loadUrl(pending.second)
            } else {
                webView.reload()
            }
            onConsumePendingLoad()
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            customViewCallback?.onCustomViewHidden()
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        AndroidView(
            factory = { webView },
            update = { view ->
                if (view.parent != null) {
                    // AndroidView handles re-parenting cleanly
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        val fsView = customFullscreenView
        if (fsView != null) {
            AndroidView(
                factory = { ctx ->
                    FrameLayout(ctx).apply {
                        setBackgroundColor(android.graphics.Color.BLACK)
                        (fsView.parent as? ViewGroup)?.removeView(fsView)
                        addView(
                            fsView,
                            FrameLayout.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )
                        )
                    }
                },
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black)
            )
        }
    }
}

private fun applyWebForceDark(webView: WebView, enabled: Boolean) {
    try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            webView.settings.isAlgorithmicDarkeningAllowed = enabled
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            @Suppress("DEPRECATION")
            webView.settings.forceDark = if (enabled) WebSettings.FORCE_DARK_ON else WebSettings.FORCE_DARK_OFF
        }
    } catch (_: Exception) {
    }
}
