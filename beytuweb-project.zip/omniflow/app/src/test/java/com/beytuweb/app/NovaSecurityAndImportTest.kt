package com.beytuweb.app

import com.beytuweb.app.chromeimport.ChromeDataImporter
import com.beytuweb.app.data.local.BookmarkEntity
import com.beytuweb.app.data.local.HistoryEntity
import com.beytuweb.app.data.local.ScanStatus
import com.beytuweb.app.data.local.ShortcutEntity
import com.beytuweb.app.security.AdBlockerEngine
import com.beytuweb.app.security.ExeSandboxAnalyzer
import com.beytuweb.app.security.FileSecurityScanner
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.nio.file.Files

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class NovaSecurityAndImportTest {

    @Test
    fun adBlockerBlocksKnownAdDomainsAndAllowsYoutubeTiktok() {
        assertTrue(AdBlockerEngine.isAdRequest("https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"))
        assertTrue(AdBlockerEngine.isAdRequest("https://analytics.tiktok.com/api/v2/pixel"))
        assertTrue(AdBlockerEngine.isAdRequest("https://adclick.g.doubleclick.net/pcs/click"))
        assertFalse(AdBlockerEngine.isAdRequest("https://m.youtube.com/watch?v=dQw4w9WgXcQ"))
        assertFalse(AdBlockerEngine.isAdRequest("https://www.tiktok.com/@user/video/123"))
    }

    @Test
    fun fileCategorizationRoutesExtensionsIntoProperFolders() {
        assertEquals("Görseller", FileSecurityScanner.categorizeFile("photo.png", "image/png"))
        assertEquals("Videolar", FileSecurityScanner.categorizeFile("clip.mp4", "video/mp4"))
        assertEquals("Belgeler", FileSecurityScanner.categorizeFile("rapor.pdf", "application/pdf"))
        assertEquals("Ses", FileSecurityScanner.categorizeFile("ses.mp3", "audio/mpeg"))
        assertEquals("Arşivler", FileSecurityScanner.categorizeFile("arsiv.zip", "application/zip"))
        assertEquals("Çalıştırılabilir", FileSecurityScanner.categorizeFile("setup.exe", "application/octet-stream"))
    }

    @Test
    fun exeSandboxParsesSamplePeAndFlagsApis() {
        val tempDir = Files.createTempDirectory("nova_test").toFile()
        try {
            val exe = ExeSandboxAnalyzer.createHarmlessSampleExe(tempDir)
            val scan = FileSecurityScanner.scanFile(exe, "https://example.com/setup.exe")
            assertTrue(scan.isExecutable)
            assertTrue(scan.sha256.length == 64)
            assertTrue(scan.status != ScanStatus.CLEAN)

            val report = ExeSandboxAnalyzer.inspect(exe)
            assertTrue(report.isValidPe)
            assertEquals("x64 (AMD64)", report.architecture)
            assertTrue(report.detectedApis.contains("VirtualAlloc"))
            assertTrue(report.sections.any { it.name == ".text" })
        } finally {
            tempDir.deleteRecursively()
        }
    }

    @Test
    fun chromeHtmlAndNovaBackupRoundTripWorks() {
        val imported = ChromeDataImporter.parseImportedText(ChromeDataImporter.SAMPLE_CHROME_EXPORT_HTML)
        assertTrue(imported.bookmarks.size >= 6)
        assertTrue(imported.bookmarks.any { it.url == "https://mail.google.com" && it.folder == "Chrome Çubuğu" })

        val backupJson = ChromeDataImporter.exportNovaBackupJson(
            bookmarks = listOf(BookmarkEntity(title = "YouTube", url = "https://youtube.com", folder = "Video")),
            history = listOf(HistoryEntity(title = "Google", url = "https://google.com")),
            shortcuts = listOf(ShortcutEntity(title = "YT", url = "https://youtube.com", badgeLetter = "Y", accentHex = 0xFFEF4444)),
            accountEmail = "beymaytekar83@gmail.com"
        )
        val restored = ChromeDataImporter.parseImportedText(backupJson)
        assertEquals(1, restored.bookmarks.size)
        assertEquals(1, restored.history.size)
        assertEquals(1, restored.shortcuts.size)
    }
}
